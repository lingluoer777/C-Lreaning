//
//  main.cpp
//  4.6.8菱形继承
//
//  Created by 翎落 on 2022/7/20.
//
//菱形继承概念：
//两个派生类继承同一个基类
//又有类同时继承两个派生类
//这种继承被称为菱形继承，或者钻石继承
//https://blog.csdn.net/Nwk0000000001/article/details/123363774?ops_request_misc=&request_id=&biz_id=102&utm_term=菱形继承&utm_medium=distribute.pc_search_result.none-task-blog-2~all~sobaiduweb~default-1-123363774.142^v32^pc_rank_34,185^v2^control&spm=1018.2226.3001.4187

#include <iostream>

using namespace std;

class Animal{
public:
    int m_Age;
};

//利用虚继承，解决菱形继承的问题
//继承之前加上关键字virtual，变为虚继承
//Animal类称为虚基类
class Sheep:virtual public Animal{};

class Camel:virtual public Animal{};

class Alpaca:public Sheep,public Camel{};

void test01()
{
    Alpaca alpaca;
    //当菱形继承，两个父类拥有相同数据，需要加作用域区分
    alpaca.Sheep::m_Age=18;
    alpaca.Camel::m_Age=28;
    cout << sizeof(Alpaca) << endl;
    cout << "alpaca.Sheep::m_Age=" << alpaca.Sheep::m_Age << endl;
    cout << "alpaca.Camel::m_Age=" << alpaca.Camel::m_Age << endl;
    //这份数据我们知道，只要有一份就可以，菱形继承导致数据有两份，资源浪费
    cout << "alpaca.m_Age=" << alpaca.m_Age << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
