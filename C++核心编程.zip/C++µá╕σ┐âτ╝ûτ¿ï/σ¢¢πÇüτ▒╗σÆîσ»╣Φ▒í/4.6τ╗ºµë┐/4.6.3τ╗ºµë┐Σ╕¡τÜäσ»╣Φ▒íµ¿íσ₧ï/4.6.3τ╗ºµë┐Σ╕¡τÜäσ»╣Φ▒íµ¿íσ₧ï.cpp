//
//  main.cpp
//  4.6.3继承中的对象模型
//
//  Created by 翎落 on 2022/7/20.
//
//问题：从父类继承过来的成员，哪些属于子类对象中？

#include <iostream>

using namespace std;

class Base{
public:
    int m_A;
protected:
    int m_B;
private:
    int m_C;
};

class Son:public Base{
public:
    int m_D;
};

void test01()
{
    //16
    //父类中所有非静态成员属性都会被子类继承下去
    //父类中私有成员属性是被编译器隐藏了，因此不能被访问，但依然被继承了
    cout << "sizeof(Son)=" << sizeof(Son) << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
