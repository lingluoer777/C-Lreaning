//
//  main.cpp
//  4.6.6继承同名静态成员处理方式
//
//  Created by 翎落 on 2022/7/20.
//
//问题：继承中同名的静态成员如何在子类对象上访问？
//静态成员和非静态成员出现同名，处理方式一致
//访问子类同名成员，直接访问即可
//访问父类同名成员，需要加作用域

#include <iostream>

using namespace std;

class Base{
public:
    static void func()
    {
        cout << "Base-func()" << endl;
    }
    static void func(int a)
    {
        cout << "Base-func(int a)" << endl;
    }
    static int m_A;
};

int Base::m_A=100;

class Son:public Base{
public:

    static void func()
    {
        cout << "Son-func()" << endl;
    }
    static int m_A;
};

int Son::m_A=200;

//同名静态成员属性
void test01()
{
    Son s1;
    //1、通过对象访问
    cout << "Son下m_A=" << s1.m_A << endl;
    cout << "Base下m_A=" << s1.Base::m_A << endl;
    //2通过类名访问
    cout << "Son下m_A=" << Son::m_A << endl;
    //第一个::代表通过类名访问，第二个::代表访问父类作用域下
    cout << "Base下m_A=" << Son::Base::m_A << endl;
}

//同名静态成员函数
void test02()
{
    Son s2;
    //1、通过对象访问
    s2.func();
    s2.Base::func();
    //2、通过类名访问
    Son::func();
    Son::Base::func();
    Son::Base::func(100);
}

int main(int argc, const char * argv[]) {
    test01();
    test02();
    return 0;
}
