//
//  main.cpp
//  4.6.5继承同名成员处理方式
//
//  Created by 翎落 on 2022/7/20.
//
//问题：当子类中出现与父类同名的成员，如何通过子类对象，访问到子类或父类中同名的数据呢？

//访问子类同名成员：直接访问即可
//访问父类同名成员：需要加作用域

#include <iostream>

using namespace std;

class Base{
public:
    Base()
    {
        m_A=100;
    }
    void func()
    {
        cout << "Base-func()" << endl;
    }
    void func(int a)
    {
        cout << "Base-func(int a)" << endl;
    }
    int m_A;
};

class Son:public Base{
public:
    Son()
    {
        m_A=200;
    }
    void func()
    {
        cout << "Son-func()" << endl;
    }
    int m_A;
};

//同名成员属性处理
void test01()
{
    Son s1;
    cout << "s1.m_A=" << s1.m_A << endl;
    //如果通过子类对象访问到父类中同名成员，需要加作用域
    cout << "Base.m_A=" << s1.Base::m_A << endl;

}

//同名成员函数处理
void test02()
{
    Son s2;
    s2.func();
    s2.Base::func();
    //如果子类中出现与父类同名的成员函数，子类的同名成员会隐藏掉父类中所有同名成员函数
    //如果想访问到父类中被隐藏的同名成员函数，需要加作用域
    //s2.func(100);//错误
    s2.Base::func(1);
}

int main(int argc, const char * argv[]) {
    test01();
    test02();
    return 0;
}
