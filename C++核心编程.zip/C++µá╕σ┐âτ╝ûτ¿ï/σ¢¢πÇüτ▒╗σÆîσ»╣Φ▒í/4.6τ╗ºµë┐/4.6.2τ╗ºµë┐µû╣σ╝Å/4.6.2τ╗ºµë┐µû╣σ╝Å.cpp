//
//  main.cpp
//  4.6.2继承方式
//
//  Created by 翎落 on 2022/7/20.
//
//继承的语法：class 子类:继承方式 父类
//class A{
//public:
//    int a;
//protected:
//    int b;
//private:
//    int c;
//};

//继承方式一共有三种
//公共继承
//class B:public A{
//public:
//    int a;
//protected:
//    int b;
//不可访问：
//    int c;
//};

//保护继承
//class C:protected A{
//protected:
//    int a;
//    int b;
//不可访问：
//    int c;
//};

//私有继承
//class D:private A{
//private:
//    int a;
//    int b;
//不可访问：
//    int c;
//};

#include <iostream>

using namespace std;

class Base{
public:
    int m_A;
protected:
    int m_B;
private:
    int m_C;
};

//继承方式

//公共继承
class Son1:public Base{
public:
    void func()
    {
        m_A=10;//父类中的公共权限成员，到子类中依然是公共权限
        m_B=10;//父类中的保护权限成员，到子类中依然是公保护权限
        //m_C=10;//父类中的私有成员，子类不可访问//可通过友元访问
    }
};

void test01()
{
    Son1 s1;
    s1.m_A=20;
    //s1.m_B=20;//Son1中m_B依然是保护权限，类外不可访问//可通过友元访问
}

//保护继承
class Son2:protected Base{
public:
    void func()
    {
        m_A=100;//父类中的公共权限成员，到子类中变为保护权限
        m_B=100;//父类中的保护权限成员，到子类中依然是公保护权限
        //m_C=100;//父类中的私有成员，子类不可访问
    }
};

void test02()
{
    Son2 s2;
    //s2.m_A=200;//Son1中m_A变为保护权限，类外不可访问
    
}

//私有继承
class Son3:private Base{
public:
    void func()
    {
        m_A=1000;//父类中的公共权限成员，到子类中变为私有权限
        m_B=1000;//父类中的保护权限成员，到子类中变为私有权限
        //m_C=1000;//父类中的私有成员，子类不可访问
    }
};

void test03()
{
    Son3 s3;
    //s3.m_A=2000;//Son3中m_A变为私有权限，类外不可访问
    
}

class GrandSon3:public Son3{
public:
    void func()
    {
        //m_A=10000;//Son3中m_A变为私有权限，子类不可访问
    }
};

int main(int argc, const char * argv[]) {
    
    return 0;
}
