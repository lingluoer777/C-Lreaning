//
//  main.cpp
//  4.6.1继承的基本语法
//
//  Created by 翎落 on 2022/7/20.
//
//4.6继承
//继承是面向对象三大特性之一
//定义一些类时，下级别的成员除了拥有上一级的特性，还有自己的特性，这个时候我们就可以考虑继承的技术，减少重复代码

#include <iostream>

using namespace std;

//继承实现页面
//公共页面类
class BasePage{
public:
    void head()
    {
        cout << "公共头部" << endl;
    }
    void tail()
    {
        cout << "公共尾部" << endl;
    }
    void left()
    {
        cout << "公共分类列表" << endl;
    }
};

//继承的好处：减少重复代码
//语法：class 子类:继承方式 父类
//子类（派生类）
//父类（基类）

//Java页面
class Java:public BasePage{
public:
    void content()
    {
        cout << "Java学科视频" << endl;
    }
};

//Python页面
class Python:public BasePage{
public:
    void content()
    {
        cout << "Python学科视频" << endl;
    }
};

//Cpp页面
class Cpp:public BasePage{
public:
    void content()
    {
        cout << "Cpp学科视频" << endl;
    }
};

void test()
{
    Java java;
    java.head();
    java.tail();
    java.left();
    java.content();
    cout << "---------------------" << endl;
    Python python;
    python.head();
    python.tail();
    python.left();
    python.content();
    cout << "---------------------" << endl;
    Cpp cpp;
    cpp.head();
    cpp.tail();
    cpp.left();
    cpp.content();
}

int main(int argc, const char * argv[]) {
    test();
    return 0;
}
