//
//  main.cpp
//  4.4.2类做友元
//
//  Created by 翎落 on 2022/7/19.
//

#include <iostream>

using namespace std;

class Building;//类声明

class GoodFriend{
public:
    GoodFriend();
    Building * building;//创建Building*型的成员变量
    void visit();//让visit可以访问Building中的私有属性
};

class Building{
    friend class GoodFriend;
public:
    Building();
    string m_LivingRoom;
private:
    string m_BedRoom;
};

//类外写成员函数
Building::Building()
{
    m_LivingRoom="livingroon";//客厅
    m_BedRoom="bedroom";//卧室
}

GoodFriend::GoodFriend()
{
    //创建建筑物对象
    building=new Building();
}

void GoodFriend::visit()
{
    cout << "GoodFriend is accessing:" << building->m_LivingRoom << endl;
    cout << "GoodFriend is accessing:" << building->m_BedRoom << endl;
}

void test()
{
    GoodFriend goodfriend;
    goodfriend.visit();
    delete goodfriend.building;
    goodfriend.building=nullptr;
    //cout << &building->m_LivingRoom << endl;//不能访问成员属性，否则程序会崩溃
    //cout << &building->m_BedRoom << endl;
}

int main(int argc, const char * argv[]) {
    test();
    return 0;
}
