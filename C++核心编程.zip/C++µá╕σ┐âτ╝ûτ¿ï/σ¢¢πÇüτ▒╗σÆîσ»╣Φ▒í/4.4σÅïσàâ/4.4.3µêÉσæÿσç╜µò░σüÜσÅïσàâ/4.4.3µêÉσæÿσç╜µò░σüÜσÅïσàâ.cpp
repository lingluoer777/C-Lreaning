//
//  main.cpp
//  4.4.3成员函数做友元
//
//  Created by 翎落 on 2022/7/19.
//

#include <iostream>

using namespace std;

class Building;

class GoodFriend{
public:
    GoodFriend();
    Building * building;//创建Building*型的成员变量
    void visit();//让visit可以访问Building中的私有属性
    void visit2();//让visit2不可以访问Building中的私有属性
};

class Building{
    friend void GoodFriend::visit();
public:
    Building();
    string m_LivingRoom;
private:
    string m_BedRoom;
};

//类外写成员函数
Building::Building()
{
    m_LivingRoom="livingroon";//客厅
    m_BedRoom="bedroom";//卧室
}

GoodFriend::GoodFriend()
{
    //创建建筑物对象
    building=new Building();
}

void GoodFriend::visit()
{
    cout << "GoodFriend is accessing:" << building->m_LivingRoom << endl;
    cout << "GoodFriend is accessing:" << building->m_BedRoom << endl;
}

void GoodFriend::visit2()
{
    cout << "GoodFriend2 is accessing:" << building->m_LivingRoom << endl;
    //cout << "GoodFriend is accessing:" << building->m_BedRoom << endl;//错误
}

void test()
{
    GoodFriend goodfriend;
    goodfriend.visit();
    goodfriend.visit2();
    delete goodfriend.building;
    goodfriend.building=nullptr;
}

int main(int argc, const char * argv[]) {
    test();
    return 0;
}

