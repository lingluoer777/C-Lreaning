//
//  main.cpp
//  4.7.1多态的基本概念及原理剖析
//
//  Created by 翎落 on 2022/7/20.
//
//多态是C++面对对象三大特性之一
//多态分为两类：
//静态多态：函数重载和运算符重载属于静态多态，复用函数名
//动态多态：派生类和虚函数实现运行时多态

//静态多态和动态多态的区别：
//静态多态的函数地址早绑定，编译阶段确定函数地址
//动态多态的函数地址晚绑定，运行阶段确定函数地址

#include <iostream>

using namespace std;

class Animal{
public:
    virtual void Speak()//类中的成员函数不属于类的对象
    {
        cout << "Animal Speaking" << endl;
    }
};

class Cat:public Animal{
public:
    //重写：函数返回值类型，函数名，函数参数列表完全相同
    void Speak()
    {
        cout << "Cat Speaking" << endl;
    }
};

class Dog:public Animal{
public:
    void Speak()
    {
        cout << "Dog Speaking" << endl;
    }
};

//地址早绑定，在编译阶段确定函数地址
//如果想Cat Speaking，那么这个函数地址就不能提前绑定，需要在运行阶段绑定，地址晚绑定

//动态多态满足条件：
//1、有继承关系
//2、子类重写父类的虚函数

//动态多态使用：
//父类的指针或引用指向子类对象
void doSpeak(Animal & animal)
{
    animal.Speak();
}

void test01()
{
    Animal animal;
    doSpeak(animal);
    Cat cat;
    doSpeak(cat);//父类中的指针或引用可以指向子类
    Dog dog;
    doSpeak(dog);
}

void test02()
{
    cout << "sizeof(Animal)=" << sizeof(Animal) << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    test02();
    return 0;
}




/*
 
class Animal{
public:
    virtual void Speak()//类中的成员函数不属于类的对象
    {
        cout << "Animal Speaking" << endl;
    }
};

class Cat:public Animal{
public:
    //重写：函数返回值类型，函数名，函数参数列表完全相同
    void Speak()
    {
        cout << "Cat Speaking" << endl;
    }
};

当子类重写父类的虚函数，

子类中的虚函数表 内部 会替换成 子类的虚函数地址



                   Animal类内部结构

                        vfptr                                            vfptr - 虚函数（虚函数表）指针
                          |
                          |                                              v-virtual
                          |
                       vftable     表内记录虚函数的地址                      f-function
                      _______________________________
                      |                             |                    ptr-pointer
                      |                             |
                      |       &Animal::Speak        |
                      |                             |
                      |                             |                    vftable - 虚函数表
                      |_____________________________|
                                                                         v-virtual

                                                                         f-function
                                Cat类内部结构
                                                                         table-表格
                         vfptr
                           |
                           |
                           |                                             当父类的指针或引用自箱子类对象时，发生多态
                        vftable     表内记录虚函数的地址
                      _______________________________                    Animal & animal=cat;
                      |                             |
                      |                             |                    animal.Speak;
                      |        &Cat::Speak          |
                      |                             |
                      |                             |
                      |_____________________________|

 */
