//
//  main.cpp
//  4.7.2多态案例1
//
//  Created by 翎落 on 2022/7/21.
//
//分别利用普通写法和多态技术，设计实现两个操作符进行运算的运算器类

#include <iostream>

using namespace std;

//普通写法
class Calculator{
public:
    double getResult(string oper)//不能传入引用
    {
        if(oper=="+")//加法
            return m_Num1+m_Num2;
        else if(oper=="-")//减法
            return m_Num1-m_Num2;
        else if(oper=="*")//乘法
            return m_Num1*m_Num2;
        else if(oper=="/")//除法
            return m_Num1/m_Num2;
        else return -1;
    }
    //如果想扩展新的功能，需求修改源码
    //在实际开发中，提倡“开闭原则”
    //开闭原则：对扩展进行开放，对修改进行关闭
    
    double m_Num1;
    double m_Num2;
};

void test01()
{
    Calculator cal;
    cal.m_Num1=5.15;
    cal.m_Num2=3.14;
    cout << cal.m_Num1 << "+" << cal.m_Num2 << "=" << cal.getResult("+") << endl;
    cout << cal.m_Num1 << "-" << cal.m_Num2 << "=" << cal.getResult("-") << endl;
    cout << cal.m_Num1 << "*" << cal.m_Num2 << "=" << cal.getResult("*") << endl;
    cout << cal.m_Num1 << "/" << cal.m_Num2 << "=" << cal.getResult("/") << endl;
}

//多态写法

//多态的优点：
//代码组织结构清晰
//可读性强
//利于前期和后期的扩展以及维护

//实现计算器抽象类
class AbstractCalculator{
public:
    virtual double getResult()
    {
        return 0;
    }
    double m_Num1;
    double m_Num2;
};

//加法类
class AddCalculator:public AbstractCalculator{
public:
    double getResult()
    {
        return m_Num1+m_Num2;
    }
};

//减法类
class SubCalculator:public AbstractCalculator{
public:
    double getResult()
    {
        return m_Num1-m_Num2;
    }
};

//乘法类
class MulCalculator:public AbstractCalculator{
public:
    double getResult()
    {
        return m_Num1*m_Num2;
    }
};

//除法类
class DivCalculator:public AbstractCalculator{
public:
    double getResult()
    {
        return m_Num1/m_Num2;
    }
};

void test02()
{
    //多态使用条件：
    //父类指针或引用指向子类对象
    
    //加法运算
    AbstractCalculator * abc=new AddCalculator;
    abc->m_Num1=5.15;
    abc->m_Num2=3.14;
    cout << abc->m_Num1 << "+" << abc->m_Num2 << "=" << abc->getResult() << endl;
    //堆区内存开辟后需要释放
    delete abc;
    abc=nullptr;
    
    //减法运算
    abc=new SubCalculator;
    abc->m_Num1=5.15;
    abc->m_Num2=3.14;
    cout << abc->m_Num1 << "-" << abc->m_Num2 << "=" << abc->getResult() << endl;
    delete abc;
    abc=nullptr;
    
    //乘法运算
    abc=new MulCalculator;
    abc->m_Num1=5.15;
    abc->m_Num2=3.14;
    cout << abc->m_Num1 << "*" << abc->m_Num2 << "=" << abc->getResult() << endl;
    delete abc;
    abc=nullptr;
    
    //除法运算
    abc=new DivCalculator;
    abc->m_Num1=5.15;
    abc->m_Num2=3.14;
    cout << abc->m_Num1 << "/" << abc->m_Num2 << "=" << abc->getResult() << endl;
    delete abc;
    abc=nullptr;
}

int main(int argc, const char * argv[]) {
    //test01();
    test02();
    return 0;
}
