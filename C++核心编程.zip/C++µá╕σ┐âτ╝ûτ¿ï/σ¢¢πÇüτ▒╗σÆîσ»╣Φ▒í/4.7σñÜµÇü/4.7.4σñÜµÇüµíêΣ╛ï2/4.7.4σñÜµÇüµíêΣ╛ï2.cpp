//
//  main.cpp
//  4.7.4多态案例2
//
//  Created by 翎落 on 2022/7/21.
//
//制作饮品的大致流称为：煮水-冲泡咖啡-倒入杯中-加入辅料
//利用多态技术实现本案例，提供抽象制作饮品基类，提供子类制作咖啡和茶叶

#include <iostream>

using namespace std;

class MakeDrinks{
public:
    virtual void BoilWater()=0;//煮水
    virtual void Brew()=0;//冲泡饮品
    virtual void PourintoCup()=0;//倒入杯中
    virtual void AddMaterial()=0;//加入材料
    void Making()
    {
        BoilWater();
        Brew();
        PourintoCup();
        AddMaterial();
    }
    virtual ~MakeDrinks() {}
};

class MakeCoffee:public MakeDrinks{
public:
    void BoilWater()
    {
        cout << "Coffee is boiling" << endl;
    }
    void Brew()
    {
        cout << "Coffee is brewing" << endl;
    }
    void PourintoCup()
    {
        cout << "Pour into cup" << endl;
    }
    void AddMaterial()
    {
        cout << "Add suagr" << endl;
        cout << "Add milk" << endl;
    }
};

class BrewTea:public MakeDrinks{
public:
    void BoilWater()
    {
        cout << "Water is boiling" << endl;
    }
    void Brew()
    {
        cout << "Water is brewing" << endl;
    }
    void PourintoCup()
    {
        cout << "Pour into cup" << endl;
    }
    void AddMaterial()
    {
        cout << "Add lemon" << endl;
    }
};

void doWork(MakeDrinks * md)
{
    md->Making();
    delete md;
    md=nullptr;
}

void Test01()
{
    doWork(new MakeCoffee);
}

void Test02()
{
    doWork(new BrewTea);
}

int main(int argc, const char * argv[]) {
    Test01();
    Test02();
    return 0;
}
