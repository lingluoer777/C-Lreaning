//
//  main.cpp
//  4.7.3纯虚函数和抽象类
//
//  Created by 翎落 on 2022/7/21.
//
//在多态中，通常父类中虚函数的实现是无意义的，主要都是调用子类重写的内容
//因此可以将虚函数该为纯虚函数
//纯虚函数语法：virtual 返回值类型 函数名(参数列表)=0;
//当类中有了纯虚函数，这个类也称为抽象类

#include <iostream>

using namespace std;

class Base{
public:
    //纯虚函数
    //只要类中有一个纯虚函数，这个类称为抽象类
    
    //抽象类特点：
    //无法实例化对象
    //子类必须重写父类中的纯虚函数，否则也属于抽象类
    
    virtual void func()=0;
    virtual ~Base()=0;
};

Base::~Base(){}

class Son:public Base{
public:
    void func()
    {
        cout << "void func()函数调用" << endl;
    }
};

void test01()
{
    //Base b;//错误，抽象类无法实例化对象
    //Base * b=new Base//错误
    //子类必须重写父类中的纯虚函数，否则也属于抽象类
    Base * base=new Son;
    base->func();
    delete base;
    base=nullptr;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
