//
//  main.cpp
//  4.7.6多态案例3
//
//  Created by 翎落 on 2022/7/21.
//
//电脑主要组成部件为CPU（用于计算），显卡（用于显示），内存条（用于存储）；
//将每个零封装出抽象基类，并且提供不同的厂商生产不同的零件，例如Intel和Lenovo；
//创建电脑类让电脑工作的函数，并且调用每个零件工作的接口；
//测试时组装三台不同的电脑进行工作；

#include <iostream>

using namespace std;

//抽象类
class CPU{
public:
    CPU()
    {
        cout << "CPU 构造" << endl;
    }
    //抽象出计算函数
    virtual void Calculate()=0;
    virtual ~CPU()
    {
        cout << "CPU 析构" << endl;
    }
};
//CPU::~CPU(){}

class GPU{
public:
    GPU()
    {
        cout << "GPU 构造" << endl;
    }
    //抽象出显示函数
    virtual void Dispaly()=0;
    virtual ~GPU()
    {
        cout << "GPU 析构" << endl;
    }
};
//GPU::~GPU(){}

class RAM{
public:
    RAM()
    {
        cout << "RAM 构造" << endl;
    }
    //抽象出存储函数
    virtual void Storage()=0;
    virtual ~RAM()
    {
        cout << "RAM析构" << endl;
    }
};
//RAM::~RAM(){}



//计算机类
class Computer{
public:
    Computer(CPU *cpu,GPU *gpu,RAM *ram)
    {
        cout << "Computer 构造" << endl;
        this->cpu=cpu;
        this->gpu=gpu;
        this->ram=ram;
    }
    void Working()
    {
        cpu->Calculate();
        gpu->Dispaly();
        ram->Storage();
    }
    //提供析构函数释放三个零件的内存
    ~Computer()
    {
        cout << "Computer析构" << endl;
        delete cpu;
        cpu=nullptr;
        delete gpu;
        gpu=nullptr;
        delete ram;
        ram=nullptr;
    }
private:
    CPU * cpu;
    GPU * gpu;
    RAM * ram;
};



//Intel
class IntelCPU:public CPU{
public:
    IntelCPU()
    {
        cout << "Intel CPU 构造" << endl;
    }
    void Calculate()
    {
        cout << "Intel CPU Working" << endl;
    }
    ~IntelCPU()
    {
        cout << "Intel CPU析构" << endl;
    }
};

class IntelGPU:public GPU{
public:
    IntelGPU()
    {
        cout << "Intel GPU 构造" << endl;
    }
    void Dispaly()
    {
        cout << "Intel GPU Working" << endl;
    }
    ~IntelGPU()
    {
        cout << "Intel GPU析构" << endl;
    }
};

class IntelRAM:public RAM{
public:
    IntelRAM()
    {
        cout << "Intel RAM 构造" << endl;
    }
    void Storage()
    {
        cout << "Intel RAM Working" << endl;
    }
    ~IntelRAM()
    {
        cout << "Intel RAM析构" << endl;
    }
};

//Lenovo
class LenovoCPU:public CPU{
public:
    LenovoCPU()
    {
        cout << "Lenovo CPU 构造" << endl;
    }
    void Calculate()
    {
        cout << "Lenovo CPU Working" << endl;
    }
    ~LenovoCPU()
    {
        cout << "Lenovo CPU析构" << endl;
    }
};

class LenovoGPU:public GPU{
public:
    LenovoGPU()
    {
        cout << "Lenovo GPU 构造" << endl;
    }
    void Dispaly()
    {
        cout << "Lenovo GPU Working" << endl;
    }
    ~LenovoGPU()
    {
        cout << "Lenovo GPU析构" << endl;
    }
};

class LenovoRAM:public RAM{
public:
    LenovoRAM()
    {
        cout << "Lenovo RAM 构造" << endl;
    }
    void Storage()
    {
        cout << "Lenovo RAM Working" << endl;
    }
    ~LenovoRAM()
    {
        cout << "Lenovo RAM析构" << endl;
    }
};



void Test01()
{
    Computer * c1=new Computer(new IntelCPU,new IntelGPU,new IntelRAM);
    c1->Working();
    delete c1;
    c1=nullptr;
    //电脑在堆区开辟被释放，但电脑的零件也是在堆区开辟但并没有被释放
    cout << "-------------------------" << endl;
    Computer * c2=new Computer(new IntelCPU,new IntelGPU,new LenovoRAM);
    c2->Working();
    delete c2;
    c2=nullptr;
    cout << "-------------------------" << endl;
    Computer * c3=new Computer(new LenovoCPU,new LenovoGPU,new LenovoRAM);
    c3->Working();
    delete c3;
    c3=nullptr;
}

int main(int argc, const char * argv[]) {
    Test01();
    return 0;
}
