//
//  Point.h
//  C++核心编程
//
//  Created by 翎落 on 2022/7/18.
//

#ifndef Point_h
#define Point_h

#include <iostream>

using namespace std;

class Point{
public:
    //设置x
    void setX(int x);
    
    //获取x
    int getX();
    
    //设置y
    void setY(int y);

    //获取y
    int getY();

private:
    int m_X;
    int m_Y;
};

#endif /* Point_h */
