//
//  Point.cpp
//  封装设计案例2
//
//  Created by 翎落 on 2022/7/18.
//

#include <stdio.h>
#include "Point.h"

//设置x
void Point::setX(int x)
{
    m_X=x;
}

//获取x
int Point::getX()
{
    return m_X;
}

//设置y
void Point::setY(int y)
{
    m_Y=y;
}

//获取y
int Point::getY()
{
    return m_Y;
}
