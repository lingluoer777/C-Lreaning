//
//  Circle.cpp
//  封装设计案例2
//
//  Created by 翎落 on 2022/7/18.
//

#include <stdio.h>
#include "Circle.h"

//设置半径
void Circle::setR(int R)
{
    m_R=R;
}

//获取半径
int Circle::getR()
{
    return m_R;
}

//设置圆心
void Circle::setCenter(Point Center)
{
    m_Center=Center;
}

//获取圆心
//一个类的对象也可以作为另一个类中的成员
Point Circle::getCenter()
{
    return m_Center;
}
