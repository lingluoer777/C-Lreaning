//
//  main.cpp
//  封装设计案例2
//
//  Created by 翎落 on 2022/7/18.
//
//设计一个圆形类(Circle),和一个点类(Point)，计算点和圆的关系

#include <iostream>
#include "Point.h"
#include "Circle.h"

using namespace std;

//判断点和圆关系
//x*x+y*y=r*r，圆上
void isInCircle(Circle &c,Point &p)
{
     int Distance=(c.getCenter().getX()-p.getX())*(c.getCenter().getX()-p.getX())+
    (c.getCenter().getY()-p.getY())*(c.getCenter().getY()-p.getY());
     int rDistance=c.getR()*c.getR();
    if(Distance==rDistance)
        cout << "点在圆上" << endl;
    else if(Distance>rDistance)
        cout << "点在圆外" << endl;
    else cout << "点在圆内" << endl;
}

int main(int argc, const char * argv[]) {
    Circle c;
    c.setR(10);
    Point Center;
    Center.setX(0);
    Center.setY(0);
    c.setCenter(Center);
    Point p;
    p.setX(10);
    p.setY(10);
    isInCircle(c,p);
    return 0;
}
