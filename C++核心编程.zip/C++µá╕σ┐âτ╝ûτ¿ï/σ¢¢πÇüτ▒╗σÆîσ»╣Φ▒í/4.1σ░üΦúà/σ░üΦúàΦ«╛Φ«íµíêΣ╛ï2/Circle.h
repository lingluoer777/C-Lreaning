//
//  Circle.h
//  C++核心编程
//
//  Created by 翎落 on 2022/7/18.
//

#ifndef Circle_h
#define Circle_h

#include <iostream>
#include "Point.h"

using namespace std;

class Circle{
public:
    //设置半径
    void setR(int R);

    //获取半径
    int getR();

    //设置圆心
    void setCenter(Point Center);

    //获取圆心
    Point getCenter();

private:
    int m_R;
    Point m_Center;
};

#endif /* Circle_h */
