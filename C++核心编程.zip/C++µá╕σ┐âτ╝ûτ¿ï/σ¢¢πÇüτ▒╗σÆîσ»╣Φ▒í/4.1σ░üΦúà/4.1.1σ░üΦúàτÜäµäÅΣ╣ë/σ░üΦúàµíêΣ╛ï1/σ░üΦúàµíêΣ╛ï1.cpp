//
//  main.cpp
//  封装案例1
//
//  Created by 翎落 on 2022/7/17.
//
//设计一个学生类，属性有姓名和学号，可以给姓名和学号赋值，可以显示学生的姓名和学号

#include <iostream>

using namespace std;

class Student{
    
public:
    
    //类中的属性和行为统称为成员
    //属性：成员属性/成员变量
    //行为：成员函数/成员方法
    
    string m_Name;
    int m_ID;
    
    void setName(string name)
    {
        m_Name=name;
    }
    
    void setID(int id)
    {
        m_ID=id;
    }
    
    void get()
    {
        cout << "m_Name=" << m_Name << endl;;
        cout << "m_ID=" << m_ID << endl;
    }
};

int main(int argc, const char * argv[]) {
    Student s1;
    s1.setName("zhangsan");
    s1.setID(123456);
    s1.get();
    return 0;
}
