//
//  main.cpp
//  4.1.1.2封装的意义2
//
//  Created by 翎落 on 2022/7/17.
//
//封装意义二：
//类在设计时，可以把属性和行为放在不同的权限下，加以控制
//访问权限有三种：
//1、public    公共权限
//2、protected 保护权限
//3、private   私有权限

#include <iostream>

using namespace std;

//三种权限
//公共权限     类内可以访问，类外可以访问
//保护权限     类内可以访问，类外不可以访问     继承时子类可以访问父类的protected成员
//私有权限     类内可以访问，类外不可以访问     继承时子类不可以访问父类的private成员

class Person{
    
    //公共权限
public:
    string m_Name;
    
    void func()
    {
        m_Name="ZhangSan";
        m_Car="baoma";
        m_Password=123456;
    }
    //保护权限
protected:
    string m_Car;

    //私有权限
private:
    int m_Password;
        
};

int main(int argc, const char * argv[]) {
    Person P1;
    P1.m_Name="LiSi";
    //P1.m_Car="benchi";//错误，protected成员在类外不可访问
    //P1.m_Password=123;//错误，private成员在类外不可访问
    P1.func();
    return 0;
}
