//
//  main.cpp
//  4.1.1.1封装的意义1
//
//  Created by 翎落 on 2022/7/17.
//
//四、类和对象
//C++面对对象的三大特性为：封装、继承、多态
//对象上有其属性和行为
//具有相同性质的对象，我们可以将其抽象为类

//4.1封装
//4.1.1封装的意义
//封装是C++面对对象三大特性之一
//封装的意义：
//将属性和行为作为一个整体
//将属性和行为加以权限控制

//封装意义一：
//在设计类时将属性和行为写在一起
//语法：class 类名{访问权限 属性/行为};

#include <iostream>

using namespace std;

const double PI=3.14;

//设计一个圆类，求圆的周长

//class代表一个类，类后面紧跟着的就是类的名称
class Circle{
    //访问权限
public:
    //属性
    double m_r;
    //行为
    double Perimeter()
    {
        return 2*PI*m_r;
    }
};

int main(int argc, const char * argv[]) {
    //实例化（通过一个类创建一个对象的过程）
    Circle c1;
    c1.m_r=1.5;
    cout << "Permimeter=" << c1.Perimeter() << endl;
    return 0;
}
