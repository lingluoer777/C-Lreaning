//
//  main.cpp
//  封装设计案例1
//
//  Created by 翎落 on 2022/7/18.
//
//设计立方体类(Cube)
//求出立方体面积和体积
//分别利用全局函数和成员函数判断两个立方体是否相等

#include <iostream>

using namespace std;

class Cube{
public:
    //设置长、宽、高
    void setSidelength(int l,int w,int h)
    {
        m_L=l;
        m_W=w;
        m_H=h;
    }
    //获取长
    int getLength()
    {
        return m_L;
    }
    //获取宽
    int getWidth()
    {
        return m_W;
    }
    //获取高
    int getHigh()
    {
        return m_H;
    }
    //获取表面积
    int Area()
    {
        return 2*(m_L*m_W+m_W*m_H+m_L*m_H);
    }
    //获取体积
    int Volume()
    {
        return m_L*m_W*m_H;
    }
    //利用成员函数判断是否相等
    bool IfEqual(Cube &c)//需要调用1个参数
    {
        if(m_L==c.getLength()&&m_W==c.getWidth()&&m_H==c.getHigh())
            return true;
        else return false;
    }
private:
    int m_L;
    int m_W;
    int m_H;
};

//利用全局函数判断是否相等
//本题中认为如果两个立方体的长、宽、高分别相等，则这两个立方体相等
bool IfEqual(Cube &c1,Cube &c2)//需要调用2个参数
{
    if(c1.getLength()==c2.getLength()&&c1.getWidth()==c2.getWidth()&&c1.getHigh()==c2.getHigh())
        return true;
    else return false;
}

int main(int argc, const char * argv[]) {
    Cube c1;
    Cube c2;
    c1.setSidelength(8,9,10);
    c2.setSidelength(8,9,10);
    cout << "c1.Area=" << c1.Area() << endl;
    cout << "c1.Volume=" << c1.Volume() << endl;
    cout << "c2.Area=" << c2.Area() << endl;
    cout << "c2.Volume=" << c2.Volume() << endl;
    if(IfEqual(c1,c2))
        cout << "c1 global equal c2" << endl;
    else cout << "c1 global not equal c2" << endl;
    if(c1.IfEqual(c2))
        cout << "c1 local equal c2" << endl;
    else cout << "c1 local not equal c2" << endl;
    return 0;
}
