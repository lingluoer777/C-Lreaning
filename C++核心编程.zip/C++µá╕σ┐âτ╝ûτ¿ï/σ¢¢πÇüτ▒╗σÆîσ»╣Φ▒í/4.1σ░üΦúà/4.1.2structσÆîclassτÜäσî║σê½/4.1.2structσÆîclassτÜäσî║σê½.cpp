//
//  main.cpp
//  4.1.2struct和class的区别
//
//  Created by 翎落 on 2022/7/18.
//
//在C++中struct和class唯一的区别就在于默认的访问权限不同

#include <iostream>

using namespace std;

class C1{
    int m_A;//默认权限为private
};

struct S1{
    int m_A;//默认权限为public
};

int main(int argc, const char * argv[]) {
    
    //struct和class区别
    //struct默认访问权限为public
    //class默认访问权限为private
    
    C1 c1;
    //c1.m_A=100;//错误
    S1 s1;
    s1.m_A=100;
    return 0;
}
