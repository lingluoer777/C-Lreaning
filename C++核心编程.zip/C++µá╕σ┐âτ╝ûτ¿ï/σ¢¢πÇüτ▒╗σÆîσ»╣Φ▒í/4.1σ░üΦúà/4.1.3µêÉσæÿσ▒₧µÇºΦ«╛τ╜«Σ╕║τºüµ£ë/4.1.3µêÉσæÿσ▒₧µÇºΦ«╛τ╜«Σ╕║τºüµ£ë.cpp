//
//  main.cpp
//  4.1.3成员属性设置为私有
//
//  Created by 翎落 on 2022/7/18.
//
//优点1:将所有成员属性设置为私有，可以自己控制读写权限
//优点2:对于写权限，我们可以检测数据的有效性

#include <iostream>

using namespace std;

class Person{
public:
    void setName(string name)
    {
        m_Name=name;
    }
    string getName()
    {
        return m_Name;
    }
    void setID(int ID)
    {
        if(ID<=0)
        {
            m_ID=0;
            cout << "请重新输入！" << endl;
            return;
        }
        m_ID=ID;
    }
    int getID()
    {
        return m_ID;
    }
    int getAge()
    {
        int m_Age=10;
        return m_Age;
    }
    void setLover(string lover)
    {
        m_Lover=lover;
    }
private:
    //可读可写
    string m_Name;
    int m_ID;
    //只读
    int m_Age;
    //只写
    string m_Lover;
};

int main(int argc, const char * argv[]) {
    Person p;
    p.setName("zhangsan");
    cout << "m_Name=" << p.getName() << endl;
    p.setID(-1);
    cout << "m_ID=" << p.getID() << endl;
    cout << "m_Age=" << p.getAge() << endl;
    p.setLover("lingluo");
    return 0;
}
