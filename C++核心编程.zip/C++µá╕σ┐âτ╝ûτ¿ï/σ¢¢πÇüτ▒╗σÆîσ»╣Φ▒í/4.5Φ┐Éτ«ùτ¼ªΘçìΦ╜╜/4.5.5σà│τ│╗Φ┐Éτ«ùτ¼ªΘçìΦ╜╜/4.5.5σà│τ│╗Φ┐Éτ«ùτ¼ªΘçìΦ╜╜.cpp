//
//  main.cpp
//  4.5.5关系运算符重载
//
//  Created by 翎落 on 2022/7/19.
//
//作用：重载关系运算符，可以让两个自定义类型对象进行对比操作

#include <iostream>

using namespace std;

class Person{
public:
    Person(string name,int age)
    {
        this->m_Name=name;
        this->m_Age=age;
    }
    //重载==运算符
    bool operator==(Person &p)
    {
        if(this->m_Name==p.m_Name&&this->m_Age==p.m_Age)
            return true;
        else return false;
    }
    //重载!=运算符
    bool operator!=(Person &p)
    {
        if(this->m_Name==p.m_Name&&this->m_Age==p.m_Age)
            return false;
        else return true;
    }
    string m_Name;
    int m_Age;
};

void test01()
{
    Person p1("zhou",18);
    Person p2("wu",18);
    if(p1==p2)
        cout << "p1==p2" << endl;
    else cout << "p1!=p2" << endl;
    
    if(p1!=p2)
        cout << "p1!=p2" << endl;
    else cout << "p1==p2" << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
