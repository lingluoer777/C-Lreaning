//
//  main.cpp
//  4.5.4赋值运算符重载
//
//  Created by 翎落 on 2022/7/19.
//
//C++编译器至少给一个类添加4个函数
//默认构造参数（无参，函数体为空）
//默认析构函数（无参，函数体为空）
//默认拷贝构造函数，对属性进行值拷贝
//赋值运算符 operator=,对属性进行值拷贝
//
//如果类中有属性指向堆区，作赋值操作时也会出现深浅拷贝问题

#include <iostream>

using namespace std;

class Person{
public:
    Person(int age)
    {
        m_Age=new int(age);
    }
    ~Person()
    {
        if(m_Age!=nullptr)
        {
            delete m_Age;
            m_Age=nullptr;
        }
    }
    Person& operator=(Person &p)
    {
        //m_Age=p.m_Age;//浅拷贝
        //应该先判断是否有属性在堆区，如果有先释放干净，然后再深拷贝
        if(m_Age!=nullptr)
        {
            delete m_Age;
            m_Age=nullptr;
        }
        //深拷贝
        m_Age=new int(*p.m_Age);
        return *this;
    }
    int* m_Age;
};

void test01()
{
    Person p1(18);
    Person p2(20);
    Person p3(30);
    p3=p2=p1;
    cout << "p1.m_Age=" << *p1.m_Age << endl;
    cout << "p2.m_age=" << *p2.m_Age << endl;
    cout << "p3.m_Age=" << *p3.m_Age << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
