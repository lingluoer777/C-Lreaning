//
//  main.cpp
//  4.5.6函数调用运算符重载
//
//  Created by 翎落 on 2022/7/19.
//
//函数调用运算符()也可以重载
//由于重载后的调用方式非常像函数的调用，因此称为仿函数
//仿函数没有固定写法，非常灵活

#include <iostream>

using namespace std;

class MyPrint{
public:
    //重载函数调用运算符
    void operator()(string text){
        cout << text << endl;
    }
};

//仿函数非常灵活，没有固定写法
class MyAdd{
public:
    int operator()(int num1,int num2){
        return num1+num2;
    }
};

void myprint(string text)
{
    cout << text << endl;
}

void test01()
{
    MyPrint myPrint;
    myPrint("hello world");//由于使用起来非常像函数，因此称为仿函数
    myprint("hello world");
}

void test02()
{
    MyAdd myAdd;
    int ret=myAdd(100,200);
    cout << "num1+num2=" << ret << endl;
    //匿名函数对象，当前行运行完后被立即释放
    cout << "num1+num2=" << MyAdd()(100,200) << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    test02();
    return 0;
}
