//
//  main.cpp
//  4.5.3递增运算符重载
//
//  Created by 翎落 on 2022/7/19.
//
//作用：通过重载递增运算符，实现自己的整型数据

#include <iostream>

using namespace std;

//自定义整型
class MyInteger{
    friend ostream& operator<<(ostream &cout,MyInteger myint);
public:
    MyInteger(int myint)
    {
        m_Num=myint;
    }
    //重载前置++运算符
    MyInteger& operator++()
    {
        ++m_Num;
        return *this;
    }
    
    //重载后置++运算符
    //不加&的原因：
    //eg:int a=0;a++;//a++=0;a=1//在执行a++时，实际上使用了一个临时变量来保存a的值，然后返回的是临时变量的值，临时变量的值不可更改
    //即(a++)++的语法是错误的
    
//    double a = 10.8;
//    const int &b = (int)a;
//    double &c = a; //也可以用const修饰c, 不会产生什么影响
//    cout << "修改前: " << endl;
//    printf("a = %g, b = %d, c = %g\n", a, b, c); //a = 10.8, b = 10, c = 10.8
//    a = 25.3;
//    cout << "修改后: " << endl;
//    printf("a = %g, b = %d, c = %g\n", a, b, c); //a = 25.3, b = 10, c = 25.3
    //b引用的并不是a，而是一个int类型的临时变量

    MyInteger operator++(int)//int代表占位参数，可以用于区分前置和后置递增
    {
        //记录当前本身的值，然后让本身的值+1，然后再返回本身的值
        MyInteger temp=*this;
        m_Num++;
        return temp;
    }
    
private:
    int m_Num;
};

//重载<<运算符
ostream& operator<<(ostream &cout,MyInteger myint)
{
    cout << "myint.m_Num=" << myint.m_Num << endl;
    return cout;
}

//前置++：先++，再返回
void test01()
{
    MyInteger myint(10);
    cout << ++myint << endl;
    cout << myint << endl;
}

//后置++：先返回，再++
void test02()
{
    MyInteger myint(10);
    cout << myint++ << endl;
    cout << myint << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    test02();
    return 0;
}

//https://blog.csdn.net/weixin_45799835/article/details/105780627?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522165823626816782350851289%2522%252C%2522scm%2522%253A%252220140713.130102334..%2522%257D&request_id=165823626816782350851289&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~top_positive~default-1-105780627-null-null.142^v32^pc_rank_34,185^v2^control&utm_term=临时变量&spm=1018.2226.3001.4187
