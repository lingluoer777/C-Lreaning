//
//  main.cpp
//  4.3.3空指针访问成员函数
//
//  Created by 翎落 on 2022/7/19.
//
//C++中空指针也是可以调用成员函数的，但是也要注意有没有用到this指针
//如果用到this指针，需要加以判断以保证代码的健壮性

#include <iostream>

using namespace std;

class Person{
public:
    void ShowClassName(){
        cout << "this is Person class" << endl;
    }
    void ShowPersonAge(){
        if(this==nullptr)
            return;
        //报错原因是传入的指针为nullptr//or NULL
        cout << "age=" << m_Age;//this->m_Age
    }
    int m_Age;
};

void test01()
{
    Person * p=nullptr;
    p->ShowClassName();
    //p->ShowPersonAge();//报错
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
