//
//  main.cpp
//  4.3.4const修饰成员函数
//
//  Created by 翎落 on 2022/7/19.
//
//常函数：
//成员函数后加const我们称这个函数为常函数
//常函数内不可以修改成员属性
//成员属性声明时加关键字mutable，在常函数中依然可以修改

//常对象：
//声明对象前加const称该对象为常对象
//常对象只能调用常函数

#include <iostream>

using namespace std;

//常函数
class Person{
public:
    Person()
    {
        
    }
    //this的本质是指针常量，指针指向不可改变
    //const Person * const this=100;
    //在成员函数后加const，修饰的是this指向，让this指向的值也不可修改
    void ShowPerson() const
    {
        
        this->m_B=100;
        m_C=300;
        //this->m_A=100;//错误
        //this==nullptr;错误
    }
    void func()
    {
        this->m_A=100;
    }
    
    int m_A;
    mutable int m_B;//特殊变量，即使在常函数中，也可以修改这个值，关键字mutable,不能加在常函数前
    static int m_C;
};

int Person::m_C=100;

void test01()
{
    Person p;
    p.ShowPerson();
}

//常对象
void test02()
{
    const Person p2;//在对象前加const，变为常对象
    //p.m_A=100;//错误
    p2.m_B=200;//m_B是特殊值，在常对象下也可修改
    
    //常对象只能调用常函数
    p2.ShowPerson();
    cout << "p2.m_C=" << p2.m_C << endl;
    //p2.func();//错误，常对象不可以调用普通成员函数，因为普通成员函数可以修改属性
    p2.m_C=200;//常函数和常对象可以修改静态变量的值
    cout << "p2.m_C=" << p2.m_C << endl;
}

int main(int argc, const char * argv[]) {
    //test01();
    test02();
    return 0;
}
