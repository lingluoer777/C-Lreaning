//
//  main.cpp
//  4.2.4构造函数调用规则
//
//  Created by 翎落 on 2022/7/18.
//
//默认情况下，C++编译器至少给一个类添加三个函数；
//1、默认构造参数（无参，函数体为空）
//2、默认析构函数（无参，函数体为空）
//3、默认拷贝构造函数，对属性进行值拷贝

#include <iostream>

using namespace std;

class Person{
public:
    //构造函数
//    Person(){
//        cout << "Person的默认构造调用" << endl;
//    }
    
    Person(int age){
        m_Age=age;
        cout << "Person的有参构造调用" << endl;
    }
    //拷贝构造函数
//    Person(const Person &p){
//        cout << "Person的拷贝构造调用" << endl;
//        m_Age=p.m_Age;
//    }
    //析构函数
    ~Person(){
        cout << "Person的析构调用" << endl;
    }
    int m_Age;
};

//构造函数调用规则
//1、如果用户定义有参构造函数，C++不再提供默认无参构造，但会提供默认拷贝构造 command+/ Line19-21andLine28-31

void test01()
{
    //Person p;//错误，未提供默认构造函数
    Person p(10);
    cout << "p.m_Age=" << p.m_Age << endl;
    Person p2(p);
    cout << "p2.m_Age=" << p2.m_Age << endl;
}

//2、如果用户定义拷贝构造函数，C++不再提供其他构造函数 command+/ Line19-21andLine23-26
void test02()
{
    //Person p;//错误，未提供默认构造函数
    //Person p(10);//错误，未提供有参构造函数
}

int main(int argc, const char * argv[]) {
    test01();
    //test02();
    return 0;
}
