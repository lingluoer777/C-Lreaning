//
//  main.cpp
//  4.2.8.2静态成员函数
//
//  Created by 翎落 on 2022/7/18.
//

#include <iostream>

using namespace std;

//静态成员函数：
//所有对象共享同一个函数；
//静态成员函数只能访问静态成员变量；

class Person{
public:
    static void func()
    {
        m_A=200;//静态成员函数只能访问静态成员变量；
        //m_B=100;//错误，静态成员函数不可以访问非静态成员变量，无法区分到底是哪个对象的属性
        cout << "static void func调用" << endl;
    }
    static int m_A;
    int m_B;
    //静态成员函数也是有访问权限的
private:
    static void func2(){
        cout << "static void func2调用" << endl;
    }
};

int Person::m_A=100;

//有两种访问方式
void test01()
{
    //1、通过对象进行访问
    Person p;
    p.func();
    //2、通过类名进行访问
    Person::func();
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
