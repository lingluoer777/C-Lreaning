//
//  main.cpp
//  4.2.5深拷贝与浅拷贝
//
//  Created by 翎落 on 2022/7/18.
//
//浅拷贝：简单的赋值操作；
//深拷贝：在堆区重新申请空间，进行拷贝操作；

#include <iostream>

using namespace std;

class Person{
public:
    //构造函数
    Person(){
        cout << "Person的无参构造调用" << endl;
    }
    
    Person(int age,int height){
        m_Age=age;
        m_Height=new int(height);
        cout << "Person的有参构造调用" << endl;
    }
    
    //自己实现拷贝构造函数，解决浅拷贝带来的问题
    Person(const Person &p){
        cout << "Person的拷贝构造调用" << endl;
        m_Age=p.m_Age;
        //m_Height=p.m_Height;//编译器默认执行的语句
        //深拷贝操作
        m_Height=new int(*p.m_Height);
    }
    
    //析构函数
    ~Person(){
        //析构代码，将堆区开辟数据做释放操作
        if(m_Height!=NULL)
        {
            delete m_Height;
            m_Height=NULL;
        }
        cout << "Person的析构调用" << endl;
    }
    int m_Age;
    int *m_Height;
};

void test01()
{
    Person p1(18,160);
    cout << "p1.m_Age=" << p1.m_Age << endl;
    cout << "p1.m_height=" << *p1.m_Height << endl;
    Person p2(p1);
    cout << "*p2.m_Age=" << p2.m_Age << endl;
    cout << "*p2.m_height=" << *p2.m_Height << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}

//
//         p1                                                         p2
//   _______________                                           _______________
//   |   int m_Age  |                                          |   int m_Age  |
//   |              |         Person p2(p1)                    |              |
//   |______18______|         如果利用编译器提供的                 |______18______|
//   |int * m_Height|         拷贝构造函数，会做浅                 |int * m_Height|------------------|
//   |              |         拷贝操作                           |              |                 |
//   |____0x0011____|                                          |____0x0011____|                  |
//         |                                                           |                         |
//         |                       堆区                                 |                         | //p1.m_Height指向新开辟的地址
//         |                     0x0011                                |                    0x0022
//         |                    ______________                         |                    ______________
//         |                    |    160     |                         |                    |    160     |
//         |-----X------------> |         X  | <-----------------------|                    |         X  |
//                              |____________|                                              |____________|
//
//                   浅拷贝带来的问题就是    浅拷贝的问题要用深拷贝来解决
//                   堆区内存重复释放
//
//if(m_Height!=NULL)
//{
//    delete m_Height;
//    m_Height=NULL;
//}
//栈先进后出，先释放p2.m_Height，使0X0011的内存已经为空，释放p1时导致堆区内存重复释放
