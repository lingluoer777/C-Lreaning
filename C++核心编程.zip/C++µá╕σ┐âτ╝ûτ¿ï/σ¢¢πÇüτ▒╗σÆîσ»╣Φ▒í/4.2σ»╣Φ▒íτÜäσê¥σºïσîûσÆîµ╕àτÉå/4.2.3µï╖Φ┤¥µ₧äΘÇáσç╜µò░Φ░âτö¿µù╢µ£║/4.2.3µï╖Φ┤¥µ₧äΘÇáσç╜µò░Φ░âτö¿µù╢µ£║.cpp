//
//  main.cpp
//  4.2.3拷贝构造函数调用时机
//
//  Created by 翎落 on 2022/7/18.
//
#include <iostream>

using namespace std;

class Person{
public:
    //构造函数
    Person(){
        cout << "Person的无参构造调用" << endl;
    }
    
    Person(int age){
        m_Age=age;
        cout << "Person的有参构造调用" << endl;
    }
    //拷贝构造函数
    Person(const Person &p){//只要不是这种类型都被称为普通构造；
        cout << "Person的拷贝构造调用" << endl;
        m_Age=p.m_Age;
    }
    //析构函数
    ~Person(){
        //将传入的人的所有属性传到被拷贝的人身上；
        cout << "Person的析构调用" << endl;
    }
    int m_Age;
};

//拷贝构造函数调用时机
//1、使用一个已经创建完毕的对象来初始化另一个对象

void test01()
{
    Person p1(10);
    cout << "p1.m_Age=" << p1.m_Age << endl;
    Person p2(p1);
    cout << "p2.m_Age=" << p2.m_Age << endl;
}

//2、值传递的方式给函数参数传值

void Work(Person p)//值传递的本质是拷贝一个实参的副本，实参将值赋给形参；
{
    
}

void test02()
{
    Person p;
    Work(p);
}

//3、以值方式返回局部对象

Person Work2()
{
    Person p;//先创建一个局部对象，局部对象的特点：用完就会被释放掉；
    cout << &p << endl;
    return p;//返回时会根据p创建一个新的对象，然后返回给test03；//注意会有编译器可能会进行优化，而观察不到拷贝的发生；
}

void test03()
{
    Person p=Work2();
    cout << &p << endl;
}

int main(int argc, const char * argv[]) {
    //test01();
    //test02();
    test03();
    return 0;
}
