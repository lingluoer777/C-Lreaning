//
//  main.cpp
//  4.2.7类对象作为类成员
//
//  Created by 翎落 on 2022/7/18.
//
//C++中类中的成员可以是另一个类的对象，我们称该成员为对象成员
//eg:
//class A{};
//class B{
//    A a;
//};
//B类中有对象A做为成员，a为对象成员

#include <iostream>

using namespace std;

class Phone{
public:
    Phone(string pName){
        m_PName=pName;
        cout << "Phone构造函数调用" << endl;
    }
    ~Phone(){
        cout << "Phone析构函数调用" << endl;
    }
    string m_PName;
};

class Person{
public:
    Person(string name,string pName):m_Name(name),m_Phone(pName)//Phone m_Phone=pName;隐式转换法
    {
        cout << "Person构造函数调用" << endl;
    }
    ~Person(){
        cout << "Person析构函数调用" << endl;
    }
    string m_Name;
    Phone m_Phone;
};

//当其他类对象作为本类成员，构造时先构造其他类对象，再构造自身，析构的顺序与构造相反

void test()
{
    Person p("zhangsan","sanxing");
    cout << "p.m_Name=" << p.m_Name << " " << "p.m_Phone=" << p.m_Phone.m_PName << endl;
}

int main(int argc, const char * argv[]) {
    test();
    return 0;
}
