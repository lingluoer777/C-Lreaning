//
//  main.cpp
//  4.2.2构造函数的分类及调用
//
//  Created by 翎落 on 2022/7/18.
//

#include <iostream>

using namespace std;

//构造函数的分类及使用
//分类
//1、按照参属分类：无参构造（默认构造），有参构造
//2、按照类型分类：普通构造，拷贝构造

class Person{
public:
    //构造函数
    Person(){
        cout << "Person的无参构造调用" << endl;
    }
    
    Person(int a){
        age=a;
        cout << "Person的有参构造调用" << endl;
    }
    //拷贝构造函数
    Person(const Person &p){//只要不是这种类型都被称为普通构造
        cout << "Person的拷贝构造调用" << endl;
        age=p.age;
    }
    //析构函数
    ~Person(){
        //将传入的人的所有属性传到被拷贝的人身上
        cout << "Person的析构调用" << endl;
    }
    int age;
};

//调用
void test01(){
    //1、括号法
    Person p1;//默认构造函数
    Person p2(10);//有参构造函数
    cout << "p2.age=" << p2.age << endl;
    Person p3(p2);//拷贝构造函数
    cout << "p3.age=" << p3.age << endl;
    
    //注意事项
    //调用默认函数构造时，不要加()
    //因为下面这行代码，编译器会认为是一个函数的声明，而不是创建一个对象
    //C++中一个函数体内可以声明另一个函数,但不可以实现
    //Person p1();
    
    //2、显示法
//    Person p1;
//    Person p2=Person(10);//有参构造
//    Person p3=Person(p2);//拷贝构造
    
    //Person(10);//匿名对象，特点：当前行执行结束后，系统会立即回收掉匿名对象
    //cout << "aaaaa" << endl;
    
    //注意事项2
    //不要利用拷贝构造函数初始化匿名对象
    //系统会认为Person(p3)=Person p3;对象的声明，p3重定义
    //Person(p3);//错误
    
    //3、隐式转换法
//    Person p4=10;//相当于Person p4=Person(10);有参构造
//    Person p5=p4;//拷贝构造
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
