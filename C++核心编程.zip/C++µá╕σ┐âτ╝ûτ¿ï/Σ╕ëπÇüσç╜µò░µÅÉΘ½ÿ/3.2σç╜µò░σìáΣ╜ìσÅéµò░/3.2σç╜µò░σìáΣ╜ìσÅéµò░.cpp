//
//  main.cpp
//  3.2函数占位参数
//
//  Created by 翎落 on 2022/7/17.
//
//C++函数列表中函数的形参列表里可以有占位参数，用来做占位，调用函数时必须填补该位置
//语法：返回值类型 函数名(数据类型) {}

#include <iostream>

using namespace std;

int func(int a,int)
{
    return a;
}

//占位参数还可以有默认参数
int func2(int a,int=10)
{
    return a;
}
int main(int argc, const char * argv[]) {
    //int i=func(10)//错误
    cout << func(10,10) << endl;
    cout << func2(10) << endl;
    return 0;
}
