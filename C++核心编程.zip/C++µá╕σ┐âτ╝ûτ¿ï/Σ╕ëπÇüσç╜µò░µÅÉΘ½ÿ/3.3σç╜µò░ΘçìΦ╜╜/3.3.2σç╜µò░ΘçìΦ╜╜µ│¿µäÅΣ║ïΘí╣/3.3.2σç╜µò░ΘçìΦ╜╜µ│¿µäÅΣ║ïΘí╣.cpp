//
//  main.cpp
//  3.3.2函数重载注意事项
//
//  Created by 翎落 on 2022/7/17.
//

#include <iostream>

using namespace std;

//函数重载注意事项
//1、引用作为重载条件
void func(int &a)//int &a=10;&a在栈区，10在全局区
{
    cout << "func(int &a)" << endl;
}

void func(const int &a)//const int &a=10;
{
    cout << "func(const int &a)" << endl;
}

//2、函数重载碰到函数默认参数
void func2(int a)
{
    cout << "func2(int a)" << endl;
}

void func2(int a,int b=10)
{
    cout << "func2(int a,int b=10)" << endl;
}

int main(int argc, const char * argv[]) {
    int a=10;
    func(a);
    func(10);
    //func2(10);//错误，当函数重载碰到默认参数，出现二义性，报错，尽量避免这种情况
    func2(10,20);
    return 0;
}
