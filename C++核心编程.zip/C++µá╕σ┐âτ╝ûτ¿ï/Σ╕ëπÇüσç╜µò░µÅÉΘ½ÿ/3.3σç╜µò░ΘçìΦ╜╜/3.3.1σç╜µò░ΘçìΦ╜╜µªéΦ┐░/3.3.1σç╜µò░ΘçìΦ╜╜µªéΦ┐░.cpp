//
//  main.cpp
//  3.3.1函数重载概述
//
//  Created by 翎落 on 2022/7/17.
//
//作用：函数名可以相同，提高复用性

#include <iostream>

using namespace std;

//函数重载满足条件：
//同一个作用域下
//函数名称相同
//函数参数类型不同或者个数不同或者顺序不同

void func()
{
    cout << "func()" << endl;
}

void func(int a)
{
    cout << "func(int a)" << endl;
}

void func(double a)
{
    cout << "func(double a)" << endl;
}

void func(int a,int b)
{
    cout << "func(int a,int b)" << endl;
}

void func(int a,double b)
{
    cout << "func(int a,double b)" << endl;
}

void func(double a,int b)
{
    cout << "func(double a,int b)" << endl;
}

//注意：函数的返回值不可以作为函数重载的条件
//int func(int a)
//{
//    cout << "func(int a)" << endl;
//}//错误

int main(int argc, const char * argv[]) {
    func();
    func(10);
    func(3.14);
    func(10,10);
    func(10,3.14);
    func(3.14,10);
    return 0;
}
