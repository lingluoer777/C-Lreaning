//
//  main.cpp
//  3.1函数默认参数
//
//  Created by 翎落 on 2022/7/17.
//
//在C++中，函数的形参列表中的形参时可以有默认值的
//语法：返回值类型 函数名(参数=默认值){}

#include <iostream>

using namespace std;

//函数默认参数
//如果我们自己传入了数据，就用自己的数据，如果没有，那么用默认值
int func(int a,int b=20,int c=30)
{
    return a+b+c;
}

//注意事项
//1、如果某个位置已经有了默认参数，那么从这个位置起到形参列表结尾，形参都必须有默认值
//int func2(int a,int b=10,int c)//错误
//{
//    return a+b+c;
//}

//2、如果函数声明有默认参数，那么函数实现就不能有默认参数
//声明和实现只能有一个有默认参数
int func3(int a,int b=20,int c=30);

//int func3(int a,int b,int c=30)//错误
//{
//    return  a+b+c;
//}

int func3(int a,int b,int c)
{
    return a+b+c;
}

int func4(int a,int b,int c);

int func4(int a,int b=20,int c=30)
{
    return a+b+c;
}

int main(int argc, const char * argv[]) {
    cout << func(10) << endl;
    cout << func(10,30) << endl;//cout=70
    
    cout << func3(10) << endl;
    cout << func3(10,30) << endl;//cout=70
    
    cout << func4(10) << endl;
    cout << func4(10,30) << endl;
    return 0;
}
