//
//  main.cpp
//  5.2.2二进制文件-读文件
//
//  Created by 翎落 on 2022/7/21.
//
//二进制方式读文件主要利用流对象调用成员函数read
//函数原型：istream& read(char * buffer,int len);
//参数解释：字符指针buffer指向内存中一段存储空间，len是读写的字节数

#include <iostream>
#include <fstream>

using namespace std;

class Person{
public:
    char m_Name[64];
    int m_Age;
};

void test01()
{
    //1、包含头文件
    
    //2、创建流对象
    ifstream ifs;
    
    //3、打开文件，判断文件是否打开成功
    ifs.open("test.txt",ios::in|ios::binary);
    if(!ifs.is_open())
    {
        cout << "打开失败" << endl;
    }
    //4、写文件
    Person p;
    ifs.read((char *)&p,sizeof(Person));
    cout << "m_Name=" << p.m_Name << endl;
    cout << "m_Age=" << p.m_Age << endl;
    
    //5、关闭文件
    ifs.close();
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
