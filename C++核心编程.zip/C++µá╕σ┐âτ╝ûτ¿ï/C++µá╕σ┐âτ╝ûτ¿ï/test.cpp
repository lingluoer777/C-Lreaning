//
//  main.cpp
//  C++核心编程
//
//  Created by 翎落 on 2022/7/16.
//

#include <iostream>

using namespace std;
int main(int argc, const char * argv[]) {
    int a=10;
    cout << a << endl;
    return 0;
}
