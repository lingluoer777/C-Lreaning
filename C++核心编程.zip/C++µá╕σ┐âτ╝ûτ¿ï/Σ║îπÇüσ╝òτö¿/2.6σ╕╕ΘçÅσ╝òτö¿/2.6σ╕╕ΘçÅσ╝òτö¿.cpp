//
//  main.cpp
//  2.6常量引用
//
//  Created by 翎落 on 2022/7/17.
//
//作用：常量引用主要用来修饰形参，防止误操作
//在函数形参列表中，可以加const修饰形参，防止形参改变实参

#include <iostream>

using namespace std;

//打印函数
void ShowValue(const int& a)
{
    cout << "a=" << a << endl;
}

int main(int argc, const char * argv[]) {
    
    //常量引用
    //使用场景：用来修饰形参，防止误操作
    
    //int a=10;
    //int& ref=10;//错误，引用必须引用合法的数据（栈区、堆区等）
    
    //加入const后，编译器将代码修改为int temp=10;const int& ref=temp;
    //const int& ref=10;
    //ref=20;//错误，加入const后变为只读，不可修改
    int a=100;
    ShowValue(a);
    return 0;
}
