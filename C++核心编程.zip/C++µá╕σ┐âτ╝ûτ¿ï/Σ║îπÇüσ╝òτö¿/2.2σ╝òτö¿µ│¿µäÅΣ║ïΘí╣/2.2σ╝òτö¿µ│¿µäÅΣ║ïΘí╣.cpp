//
//  main.cpp
//  2.2引用注意事项
//
//  Created by 翎落 on 2022/7/17.
//
//引用必须初始化
//引用在初始化后不可改变

#include <iostream>

using namespace std;

int main(int argc, const char * argv[]) {
    
    //1、引用必须初始化
    
    int a=10;
    
    //int &b;//错误，引用必须初始化
    int &b=a;
    
    //2、引用在初始化后不可以更改
    
    //int &b=c;//错误
    int c=20;
    
    b=c;//赋值操作，不是引用
    cout << "a=" << a << endl;//cout=20
    cout << "b=" << b << endl;//cout=20
    cout << "c=" << c << endl;//cout=20
    
    return 0;
}
