//
//  main.cpp
//  2.1引用的基本使用
//
//  Created by 翎落 on 2022/7/17.
//
//作用：给变量起别名
//语法：数据类型 &别名=原名;

//              a-> |  10  |
//               |
//               b
#include <iostream>

using namespace std;

int main(int argc, const char * argv[]) {
    
    int a=10;
    int &b=a;
    //&10;//错误
    cout << "a=" << a << endl;
    cout << "b=" << b << endl;
    
    //a和b指向的是同一块内存
    cout << &a << endl;
    cout << &b << endl;
    
    b=100;
    
    cout << "a=" << a << endl;
    cout << "b=" << b << endl;
    
    return 0;
}
