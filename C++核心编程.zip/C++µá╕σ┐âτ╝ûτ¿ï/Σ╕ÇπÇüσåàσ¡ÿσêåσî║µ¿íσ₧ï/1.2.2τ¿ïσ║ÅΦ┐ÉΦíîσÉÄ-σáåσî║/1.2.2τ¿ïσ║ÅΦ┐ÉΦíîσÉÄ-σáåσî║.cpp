//
//  main.cpp
//  1.2.2程序运行后-堆区
//
//  Created by 翎落 on 2022/7/16.
//
//堆区
//由程序员分配释放，若程序员不释放，则在程序结束后由操作系统回收
//在C++中主要利用new在堆区开辟内存

#include <iostream>

using namespace std;

int* func(){
    //利用new关键字，可以将数据开辟到堆区
    
    int* p=new int(10);
    return p;
}

int main(int argc, const char * argv[]) {
    //在堆区开辟数据
    //指针本质上也是局部变量，放在栈区，指针保存的数据存放在堆区
    int* p=func();
    cout << *p << endl;//cout=10
    cout << *p << endl;//cout=10
    return 0;
}
