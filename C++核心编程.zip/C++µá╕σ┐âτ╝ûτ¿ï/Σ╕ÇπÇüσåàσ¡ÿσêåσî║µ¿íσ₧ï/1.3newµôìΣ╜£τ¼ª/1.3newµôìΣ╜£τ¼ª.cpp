//
//  main.cpp
//  1.3new操作符
//
//  Created by 翎落 on 2022/7/16.
//
//C++中利用new操作符在堆区开辟数据
//堆区开辟的数据由程序员手动开辟，手动释放，释放利用操作符delete
//语法：new 数据类型
//利用new创建数据，会返回该数据对应数据类型的指针

#include <iostream>

using namespace std;

int* func(){
    //在堆区创建整型数据
    //new返回的是该数据类型的指针
    int* p=new int(10);
    return p;
}

//1、new的基本用法
void test1(){
    int* p=func();
    cout << *p << endl;
    cout << *p << endl;
    //如果想释放堆区数据，利用关键字delete
    delete p;
    //cout << *p << endl;//内存已被释放，再次访问就是非法操作
}

//2、利用new在堆区开辟数组
void test2(){
    int* arr=new int[10];
    for(int i=0;i<10;i++)
    {
        arr[i]=i+100;
    }
    for(int j=0;j<10;j++)
    {
        cout << arr[j] << endl;
    }
    //释放堆区数组
    //释放数组时，要加[]才可以
    delete[] arr;
}

int main(int argc, const char * argv[]) {
    test1();
    test2();
    return 0;
}
