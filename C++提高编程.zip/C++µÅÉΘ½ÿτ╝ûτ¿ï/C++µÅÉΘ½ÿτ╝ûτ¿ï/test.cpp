//
//  main.cpp
//  C++提高编程
//
//  Created by 翎落 on 2022/7/22.
//

#include <iostream>

using namespace std;

int main(int argc, const char * argv[]) {
    
    return 0;
}
