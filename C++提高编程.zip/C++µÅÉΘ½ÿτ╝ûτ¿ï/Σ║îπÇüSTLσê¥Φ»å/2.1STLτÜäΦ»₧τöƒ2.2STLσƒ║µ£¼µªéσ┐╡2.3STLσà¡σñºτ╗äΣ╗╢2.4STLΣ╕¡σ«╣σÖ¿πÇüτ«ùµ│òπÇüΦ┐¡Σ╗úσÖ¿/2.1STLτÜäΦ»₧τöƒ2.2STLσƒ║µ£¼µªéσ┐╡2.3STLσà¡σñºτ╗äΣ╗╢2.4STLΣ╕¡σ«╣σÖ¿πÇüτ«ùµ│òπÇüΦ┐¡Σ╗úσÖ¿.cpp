//
//  main.cpp
//  2.1STL的诞生2.2STL基本概念2.3STL六大组件2.4STL中容器、算法、迭代器
//
//  Created by 翎落 on 2022/7/24.
//

#include <iostream>

using namespace std;

int main(int argc, const char * argv[]) {
    cout << "hello world" << endl;
    return 0;
}
