//
//  main.cpp
//  2.5.2vector存放自定义数据类型
//
//  Created by 翎落 on 2022/7/24.
//

#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

class Person
{
public:
    Person(string name,int age)
    {
        m_Name=name;
        m_Age=age;
    }
    string m_Name;
    int m_Age;
};

void myPrint01(Person &p)
{
    cout << "m_Name=" << p.m_Name << endl;
    cout << "m_Age=" << p.m_Age << endl;
}

void test01()
{
    vector<Person>v;
    Person p1("Tom",20);
    Person p2("Jay",37);
    Person p3("Shm",29);
    Person p4("Anl",18);
    Person p5("Quan",10);
    v.push_back(p1);
    v.push_back(p2);
    v.push_back(p3);
    v.push_back(p4);
    v.push_back(p5);
//    for(vector<Person>::iterator it=v.begin();it!=v.end();it++)
//    {
//        cout << "m_Name=" << (*it).m_Name << endl;
//        cout << "m_Age=" << (*it).m_Age << endl;
//    }
//    for(vector<Person>::iterator it=v.begin();it!=v.end();it++)
//    {
//        cout << "m_Name=" << it->m_Name << endl;
//        cout << "m_Age=" << it->m_Age << endl;
//    }
    for_each(v.begin(), v.end(), myPrint01);
}

void myPrint02(Person* p)
{
    cout << "m_Name=" << p->m_Name << endl;
    cout << "m_Age=" << p->m_Age << endl;
}

void test02()
{
    vector<Person*>v;
    Person p1("Tom",20);
    Person p2("Jay",37);
    Person p3("Shm",29);
    Person p4("Anl",18);
    Person p5("Quan",10);
    v.push_back(&p1);
    v.push_back(&p2);
    v.push_back(&p3);
    v.push_back(&p4);
    v.push_back(&p5);
//    for(vector<Person*>::iterator it=v.begin();it!=v.end();it++)
//    {
//        cout << "m_Name=" << (*it)->m_Name << endl;
//        cout << "m_Age=" << (*it)->m_Age << endl;
//    }
    for_each(v.begin(), v.end(), myPrint02);
}

int main(int argc, const char * argv[]) {
    //test01();
    test02();
    return 0;
}
