//
//  main.cpp
//  5.1.1 for_each
//
//  Created by 翎落 on 2022/7/28.
//
//作用：实现遍历容器
//函数原型：
//   for_each(iterator beg,iterator end,_func)
//   beg      开始迭代器
//   end      结束迭代器
//   _func    函数或者函数对象

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

void Print01(int val)
{
    cout << val << " ";
}

class Print02{
public:
    void operator()(int val)
    {
        cout << val << " ";
    }
};

void test01()
{
    vector<int>v;
    for(int i=0;i<10;i++)
    {
        v.push_back(i);
    }
    //普通函数传入函数
    for_each(v.begin(), v.end(), Print01);
    cout << endl;
    
    //仿函数传入函数对象
    for_each(v.begin(), v.end(), Print02());
    cout << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
