//
//  main.cpp
//  5.1.2 transform
//
//  Created by 翎落 on 2022/7/28.
//
//作用：搬运容器到另一个容器中
//函数原型：
//   transform(iterator beg1,iterator end1,iterator beg2,_func);
//   beg1     源容器开始迭代器
//   end1     源容器结束迭代器
//   beg2     目标容器开始迭代器
//   _func    函数或函数对象//实现一些运算

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

class Transform{
public:
    int operator()(int val)
    {
        return val+10;
    }
};

class MyPrint{
public:
    void operator()(int val)
    {
        cout << val << " ";
    }
};

void test01()
{
    vector<int>v;
    for(int i=0;i<10;i++)
    {
        v.push_back(i);
    }
    
    //目标容器
    vector<int>v2;
    //目标容器需要提前开辟空间
    v2.resize(v.size());
    transform(v.begin(), v.end(), v2.begin(), Transform());
    for_each(v2.begin(), v2.end(), MyPrint());
    cout << endl;
    
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
