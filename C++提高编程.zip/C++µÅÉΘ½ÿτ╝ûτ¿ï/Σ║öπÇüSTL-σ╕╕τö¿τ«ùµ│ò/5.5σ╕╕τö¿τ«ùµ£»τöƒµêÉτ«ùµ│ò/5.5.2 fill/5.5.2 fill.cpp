//
//  main.cpp
//  5.5.2 fill
//
//  Created by 翎落 on 2022/7/29.
//
//函数原型：
//   fill(iterator beg,iterator end,value);
//向容器中填充元素
//以填充的值来替换区间内的所有元素
//   beg           开始迭代器
//   end           结束迭代器
//   value         填充的值

#include <iostream>
#include <vector>
#include <numeric>

using namespace std;

class myPrint{
public:
    void operator()(int val)
    {
        cout << val << " ";
    }
};

void test01()
{
    vector<int>v;
    v.push_back(3);
    v.push_back(1);
    v.push_back(0);
    v.push_back(4);
    v.push_back(0);
    v.push_back(0);
    
    for_each(v.begin(), v.end(), myPrint());
    cout << endl;
    
    fill(v.begin(), v.end(), 7);
    
    for_each(v.begin(), v.end(), myPrint());
    cout << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
