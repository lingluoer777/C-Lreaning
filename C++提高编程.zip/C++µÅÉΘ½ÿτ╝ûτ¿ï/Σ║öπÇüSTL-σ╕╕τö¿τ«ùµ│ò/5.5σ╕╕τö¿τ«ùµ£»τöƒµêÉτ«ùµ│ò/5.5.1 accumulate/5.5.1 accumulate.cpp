//
//  main.cpp
//  5.5.1 accumulate
//
//  Created by 翎落 on 2022/7/29.
//
//函数原型：
//   accumulate(iterator beg,iterator end,value)
//计算容器元素累计总和
//   beg           开始迭代器
//   end           结束迭代器
//   value         起始值

#include <iostream>
#include <vector>
#include <numeric>

using namespace std;

void test01()
{
    vector<int>v;
    for(int i=0;i<10;i++)
    {
        v.push_back(i);
    }
    
    //value:起始累加值
    int sum=accumulate(v.begin(), v.end(), 20);
    cout << sum << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
