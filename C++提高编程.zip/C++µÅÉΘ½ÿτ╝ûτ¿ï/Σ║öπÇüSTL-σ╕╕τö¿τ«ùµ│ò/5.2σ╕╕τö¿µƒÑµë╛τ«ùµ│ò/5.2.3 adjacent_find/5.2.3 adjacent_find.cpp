//
//  main.cpp
//  5.2.3 adjacent_find
//
//  Created by 翎落 on 2022/7/28.
//
//作用：查找相邻重复元素
//函数原型：
//   adjacent_find(iterator beg,iterator end);
//若找到返回相邻元素第一个位置的迭代器，若没找到返回end()迭代器
//   beg     开始迭代器
//   end     结束迭代器

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

void test01()
{
    vector<int>v;
    v.push_back(0);
    v.push_back(2);
    v.push_back(3);
    v.push_back(5);
    v.push_back(6);
    v.push_back(6);
    v.push_back(8);
    v.push_back(6);
    
    vector<int>::iterator it=adjacent_find(v.begin(), v.end());
    if(it==v.end())
        cout << "no" << endl;
    else
    {
        cout << "yes" << endl;
        cout << *it << endl;
    }
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
