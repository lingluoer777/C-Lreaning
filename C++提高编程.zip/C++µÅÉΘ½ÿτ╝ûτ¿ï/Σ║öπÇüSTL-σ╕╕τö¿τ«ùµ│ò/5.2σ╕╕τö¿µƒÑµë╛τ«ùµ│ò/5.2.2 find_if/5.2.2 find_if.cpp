//
//  main.cpp
//  5.2.2 find_if
//
//  Created by 翎落 on 2022/7/28.
//
//作用：按条件查找元素
//函数原型：
//   find_if(iterator beg,iterator end,_Pred);
//   beg       开始迭代器
//   end       结束迭代器
//   _Pred     函数或者谓词（返回bool类型的仿函数）

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

//查找自定义数据类型
class Greater5{
public:
    bool operator()(int val)
    {
        return val>5;
    }
};

void test01()
{
    vector<int>v;
    for(int i=0;i<10;i++)
    {
        v.push_back(i);
    }
    vector<int>::iterator it=find_if(v.begin(), v.end(), Greater5());
    //输出大于5的所有元素
    for(;it!=v.end();it++)
    {
        if(it==v.end())
            cout << "no" << endl;
        else
        {
            cout << "yes" << endl;
            cout << *it << endl;
        }
    }
    //输出单个
//    if(it==v.end())
//        cout << "no" << endl;
//    else
//    {
//        cout << "yes" << endl;
//        cout << *it << endl;
//    }
    
}

//查找自定义数据类型
class Person{
public:
    Person(string name,int age)
    {
        m_Name=name;
        m_Age=age;
    }

    string m_Name;
    int m_Age;
};

class Greater20{
public:
    bool operator()(const Person &p)
    {
        return p.m_Age>20;
    }
};

void test02()
{
    Person p1("aaa",10);
    Person p2("bbb",20);
    Person p3("ccc",30);
    Person p4("ddd",40);
    
    vector<Person>v;
    v.push_back(p1);
    v.push_back(p2);
    v.push_back(p3);
    v.push_back(p4);
    
    vector<Person>::iterator it=find_if(v.begin(),v.end(),Greater20());
    for(;it!=v.end();it++)
    {
        if(it==v.end())
            cout << "no" << endl;
        else
        {
            cout << "yes" << endl;
            cout << "m_Name=" << it->m_Name << " m_Age=" << it->m_Age << endl;
        }
    }
    
//    if(it==v.end())
//        cout << "no" << endl;
//    else
//    {
//        cout << "yes" << endl;
//        cout << "m_Name=" << it->m_Name << " m_Age=" << it->m_Age << endl;
//    }
}

int main(int argc, const char * argv[]) {
    //test01();
    test02();
    return 0;
}
