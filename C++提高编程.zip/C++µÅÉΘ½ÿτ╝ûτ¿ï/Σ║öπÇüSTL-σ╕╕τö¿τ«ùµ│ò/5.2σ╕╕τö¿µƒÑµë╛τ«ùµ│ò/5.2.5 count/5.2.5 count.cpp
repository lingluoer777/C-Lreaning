//
//  main.cpp
//  5.2.5 count
//
//  Created by 翎落 on 2022/7/28.
//
//作用：统计元素出现次数
//函数原型：
//   count(ierator beg,iterator end,value)
//   beg        开始迭代器
//   end        结束迭代器
//   value      查找的元素

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

//统计内置数据类型
void test01()
{
    vector<int>v;
    v.push_back(10);
    v.push_back(20);
    v.push_back(30);
    v.push_back(40);
    v.push_back(20);
    v.push_back(20);
    
    unsigned long num=count(v.begin(),v.end(),20);
    cout << num << endl;
}

//统计内置数据类型
class Person{
public:
    Person(string name,int age)
    {
        m_Name=name;
        m_Age=age;
    }
    
    //重载==操作符规定计数规则
    bool operator==(const Person &p)
    {
        if(m_Age==p.m_Age)
            return true;
        else
            return false;
    }
    
    string m_Name;
    int m_Age;
};

void test02()
{
    Person p1("aaa",10);
    Person p2("bbb",20);
    Person p3("ccc",40);
    Person p4("ddd",30);
    Person p5("eee",30);
    Person p6("fff",30);
    
    vector<Person>v;
    v.push_back(p1);
    v.push_back(p2);
    v.push_back(p3);
    v.push_back(p4);
    v.push_back(p5);
    v.push_back(p6);
    
    Person p7("ggg",30);
    
    unsigned long num=count(v.begin(),v.end(),p7);
    cout << num << endl;
}

int main(int argc, const char * argv[]) {
    //test01();
    test02();
    return 0;
}
