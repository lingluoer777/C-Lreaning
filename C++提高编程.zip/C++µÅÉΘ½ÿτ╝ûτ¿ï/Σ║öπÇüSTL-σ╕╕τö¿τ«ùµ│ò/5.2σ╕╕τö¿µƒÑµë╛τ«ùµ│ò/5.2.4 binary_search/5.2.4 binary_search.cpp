//
//  main.cpp
//  5.2.4 binary_search
//
//  Created by 翎落 on 2022/7/28.
//
//函数原型：
//   bool binary_search(iterator beg,iterator end,value);
//查找指定元素，查到返回true，否则返回false
//注意：在无序序列中不可用
//   beg        开始迭代器
//   end        结束迭代器
//   value      查找的元素

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

class myCompare{
public:
    bool operator()(int val1,int val2)
    {
        return val1>val2;
    }
};

void test01()
{
    vector<int>v;
    for(int i=10;i>0;i--)
    {
        v.push_back(i);
    }
    //若不添加自定义排序规则则序列必须为升序序列
    bool ret=binary_search(v.begin(), v.end(), 9, myCompare());
    if(ret==1)
        cout << "yes" << endl;
    else
        cout << "no" << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
