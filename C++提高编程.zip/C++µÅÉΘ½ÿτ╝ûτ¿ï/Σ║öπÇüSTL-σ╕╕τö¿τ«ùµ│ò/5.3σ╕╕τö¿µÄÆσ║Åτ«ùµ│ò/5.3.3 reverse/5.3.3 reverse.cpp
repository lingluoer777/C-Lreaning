//
//  main.cpp
//  5.3.3 reverse
//
//  Created by 翎落 on 2022/7/29.
//
//函数原型：
//   revserse(iterator beg,iterator end);
//反转指定范围的元素
//   beg      开始迭代器
//   end      结束迭代器

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

void myPrint(int val)
{
    cout << val << " ";
}

void test01()
{
    vector<int>v;
    v.push_back(10);
    v.push_back(30);
    v.push_back(40);
    v.push_back(20);
    v.push_back(50);
    for_each(v.begin(), v.end(), myPrint);
    cout << endl;
    
    reverse(v.begin(), v.end());
    
    for_each(v.begin(), v.end(), myPrint);
    cout << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
