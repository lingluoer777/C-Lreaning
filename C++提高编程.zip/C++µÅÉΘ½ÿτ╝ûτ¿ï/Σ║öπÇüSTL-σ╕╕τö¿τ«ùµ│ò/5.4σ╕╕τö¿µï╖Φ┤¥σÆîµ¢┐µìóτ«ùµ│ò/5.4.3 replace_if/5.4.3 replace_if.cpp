//
//  main.cpp
//  5.4.3 replace_if
//
//  Created by 翎落 on 2022/7/29.
//
//函数原型：
//   replace_if(operator beg,operator end,_Pred,newvalue)
//按条件替换元素，满足条件的替换成新元素
//   beg          开始迭代器
//   end          结束迭代器
//   _Pred        谓词
//   newvalue     新元素

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

class Greater30{
public:
    bool operator()(int val)
    {
        return val>=30;
    }
};

class myPrint{
public:
    void operator()(int val)
    {
        cout << val << " ";
    }
};

void test01()
{
    vector<int>v;
    v.push_back(10);
    v.push_back(30);
    v.push_back(40);
    v.push_back(20);
    v.push_back(30);
    v.push_back(40);
    
    for_each(v.begin(), v.end(), myPrint());
    cout << endl;
    
    replace_if(v.begin(), v.end(), Greater30(), 15);
    
    for_each(v.begin(), v.end(), myPrint());
    cout << endl;
    
    
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
