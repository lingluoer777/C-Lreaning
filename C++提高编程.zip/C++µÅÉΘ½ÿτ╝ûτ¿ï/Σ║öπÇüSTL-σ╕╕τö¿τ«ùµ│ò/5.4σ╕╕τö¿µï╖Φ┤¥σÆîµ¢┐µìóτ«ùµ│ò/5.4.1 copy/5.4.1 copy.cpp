//
//  main.cpp
//  5.4.1 copy
//
//  Created by 翎落 on 2022/7/29.
//
//函数原型：
//   copy(iteraotr beg,iterator end,iterator dest);
//   beg        起始迭代器
//   end        结束迭代器
//   dest       目标起始迭代器

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

void myPrint(int val)
{
    cout << val << " ";
}

void test1()
{
    vector<int>v1;
    for(int i=0;i<5;i++)
    {
        v1.push_back(i);
    }
    vector<int>v2;
    v2.resize(v1.size());
    copy(v1.begin(), v1.end(), v2.begin());
    for_each(v2.begin(), v2.end(), myPrint);
}

int main(int argc, const char * argv[]) {
    test1();
    return 0;
}
