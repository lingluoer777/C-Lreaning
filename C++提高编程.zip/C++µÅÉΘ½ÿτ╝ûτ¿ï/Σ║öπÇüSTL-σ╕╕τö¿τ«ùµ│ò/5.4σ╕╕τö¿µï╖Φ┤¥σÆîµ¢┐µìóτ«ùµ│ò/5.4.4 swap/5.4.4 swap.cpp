//
//  main.cpp
//  5.4.4 swap
//
//  Created by 翎落 on 2022/7/29.
//
//函数原型：
//   swap(container c1,container c2);
//交换两个容器的元素
//   c1   容器1
//   c2   容器2

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

class myPrint{
public:
    void operator()(int val)
    {
        cout << val << " ";
    }
};

void test01()
{
    vector<int>v1;
    vector<int>v2;
    
    for(int i=0;i<4;i++)
    {
        v1.push_back(i);
    }
    for(int i=0;i<6;i++)
    {
        v2.push_back(i+2);
    }
    
    for_each(v1.begin(), v1.end(), myPrint());
    cout << endl;
    for_each(v2.begin(), v2.end(), myPrint());
    cout << endl;
    
    swap(v1,v2);
    
    for_each(v1.begin(), v1.end(), myPrint());
    cout << endl;
    for_each(v2.begin(), v2.end(), myPrint());
    cout << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
