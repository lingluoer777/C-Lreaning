//
//  main.cpp
//  5.4.2 replace
//
//  Created by 翎落 on 2022/7/29.
//
//函数原型：
//   replace(iterator beg,iterator end,oldvalue,newvalue);
//将区间内旧元素替换成新元素
//   beg             开始迭代器
//   end             结束迭代器
//   oldvalue        旧元素
//   newvalue        新元素

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

class myPrint{
public:
    void operator()(int val)
    {
        cout << val << " ";
    }
};

void test01()
{
    vector<int>v;
    v.push_back(10);
    v.push_back(20);
    v.push_back(30);
    v.push_back(20);
    v.push_back(10);
    v.push_back(20);
    
    for_each(v.begin(), v.end(), myPrint());
    cout << endl;
    
    //将区间内所有20替换成25
    replace(v.begin(), v.end(), 20, 25);
    
    for_each(v.begin(), v.end(), myPrint());
    cout << endl;
    
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
