//
//  main.cpp
//  5.6.3 set_difference
//
//  Created by 翎落 on 2022/7/29.
//
//函数原型：
//   set_union(iterator beg1,iterator end1,iterator beg2,iterator end2,iteraotr dest);
//求两个集合的差集
//v1-v2:v1有而v2没有的元素集合
//v2-v1:v2有而v1没有的元素集合
//注意：两集合必须是有序序列
//   beg1         容器1开始迭代器
//   end1         容器1结束迭代器
//   beg2         容器2开始迭代器
//   end2         容器2结束迭代器
//   dest         目标容器开始迭代器

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

void myPrint(int val)
{
    cout << val << " ";
}

void test01()
{
    vector<int>v1;
    vector<int>v2;
    
    for(int i=0;i<10;i++)
    {
        v1.push_back(i);
        v2.push_back(i+5);
    }
    
    vector<int>v;
    //最特殊情况：两容器没有交集
    //若v1-v2,则取v1.size();
    //若v2-v1，则取v2.size();
    //在这里为演示方便，取max(v1.size(),v2.size());
    v.resize(max(v1.size(),v2.size()));
    
    //v1-v2
    vector<int>::iterator itEnd=set_difference(v1.begin(), v1.end(), v2.begin(), v2.end(), v.begin());
    
    for_each(v.begin(), itEnd, myPrint);
    cout << endl;
    
    //v2-v1
    itEnd=set_difference(v2.begin(), v2.end(), v1.begin(), v1.end(), v.begin());
    
    for_each(v.begin(), itEnd, myPrint);
    cout << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
