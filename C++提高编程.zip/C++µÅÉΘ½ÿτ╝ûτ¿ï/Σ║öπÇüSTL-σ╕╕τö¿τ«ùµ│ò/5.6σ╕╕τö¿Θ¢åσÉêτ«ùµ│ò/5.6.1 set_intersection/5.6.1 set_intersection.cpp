//
//  main.cpp
//  5.6.1 set_intersection
//
//  Created by 翎落 on 2022/7/29.
//
//函数原型：
//   set_intersection(iterator beg1,iterator end1,iterator beg2,iterator end2,iteraotr dest);
//求两个集合的交集
//注意：两集合必须是有序序列
//   beg1         容器1开始迭代器
//   end1         容器1结束迭代器
//   beg2         容器2开始迭代器
//   end2         容器2结束迭代器
//   dest         目标容器开始迭代器

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

void myPrint(int val)
{
    cout << val << " ";
}

void test01()
{
    vector<int>v1;
    vector<int>v2;
    
    for(int i=0;i<10;i++)
    {
        v1.push_back(i);
        v2.push_back(i+5);
    }
    
    vector<int>v;
    //最特殊情况：大容器包括小容器，取两者size最小值
    v.resize(min(v1.size(), v2.size()));
    
    vector<int>::iterator itEnd=set_intersection(v1.begin(), v1.end(), v2.begin(), v2.end(), v.begin());
    
    //why not v.end()
    //新容器的size不一定是两者交集元素数目，去除新容器的0元素
    for_each(v.begin(), itEnd, myPrint);
    cout << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
