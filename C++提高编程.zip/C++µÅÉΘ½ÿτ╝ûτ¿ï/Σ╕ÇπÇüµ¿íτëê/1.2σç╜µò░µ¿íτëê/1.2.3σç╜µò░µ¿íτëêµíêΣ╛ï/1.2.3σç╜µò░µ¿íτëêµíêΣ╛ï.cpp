//
//  main.cpp
//  1.2.3函数模版案例
//
//  Created by 翎落 on 2022/7/22.
//
//案例描述
//利用函数模版封装一个排序的函数，可以对不同数据类型数组进行排序
//排序规则从大到小，排序算法为选择排序
//分别利用char数组和int数组进行测试

#include <iostream>

using namespace std;

//交换函数模版
template<typename T>
void mySwap(T &a,T &b)
{
    T temp=a;
    a=b;
    b=temp;
}

//选择排序算法模版
template<typename T>
void mySort(T arr[],int len)
{
    for(int i=0;i<len;i++)
    {
        int max=i;//设定最大值下标
        for(int j=i+1;j<len;j++)
        {
            //设定的最大值要比遍历出的数值小，说明j下标的元素才是最大值
            if(arr[max]<arr[j])
            {
                max=j;//更新最大值下标
            }
        }
        if(max!=i)
            mySwap(arr[max],arr[i]);
    }
}

//提供打印数组模版
template<typename T>
void printArray(T arr[],int len)
{
    for(int i=0;i<len;i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;
}

void test01()
{
    int arr[]={7,9,4,8,2,5,3,6};
    int len=sizeof(arr)/sizeof(arr[0]);
    mySort(arr,len);
    printArray(arr,len);
}

void test02()
{
    char arr[]="dbhijf";
    int len=sizeof(arr)/sizeof(arr[0])-1;
    mySort(arr,len);
    printArray(arr,len);
}

int main(int argc, const char * argv[]) {
    test01();
    test02();
    return 0;
}
