//
//  main.cpp
//  1.2.6模版的局限性
//
//  Created by 翎落 on 2022/7/22.
//
//模版的局限性：
//模版并不是万能的，有些特定的数据类型，需要具体化方式作特殊实现

#include <iostream>

using namespace std;

class Person{
public:
    Person(string name,int age)
    {
        m_Name=name;
        m_Age=age;
    }
    string m_Name;
    int m_Age;
};

//普通函数模版
template<typename T>
bool myCompare(T &a,T &b)
{
    if(a==b)
        return true;
    else
        return false;
}
//具体化，显示具体化的模型和定义，以template<>开头，并通过名称来指定类型
//利用具体化Person的版本实现代码，具体化优先调用
template<>
bool myCompare(Person &p1,Person &p2)
{
    if(p1.m_Name==p2.m_Name&&p1.m_Age==p2.m_Age)
        return true;
    else
        return false;
}

void test01()
{
    int a=10;
    int b=20;
    bool ret=myCompare(a,b);
    if(ret==1)
        cout << "a==b" << endl;
    else cout << "a!=b" << endl;
}

void test02()
{
    Person p1("Joy",10);
    Person p2("Joy",18);
    bool ret=myCompare(p1,p2);
    if(ret==1)
        cout << "p1==p2" << endl;
    else
        cout << "p1!=p2" << endl;
}

int main(int argc, const char * argv[]) {
    //test01();
    test02();
    return 0;
}
