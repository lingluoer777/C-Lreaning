//
//  main.cpp
//  1.2.5普通函数与函数模版调用规则
//
//  Created by 翎落 on 2022/7/22.
//
//调用规则如下：
//如果函数模版和普通函数都可以实现，优先使用普通函数
//可以通过空模版参数列表来强制调用函数模版
//函数模版也可以发生重载
//如果函数模版可以产生更好的匹配，优先使用函数模版

#include <iostream>

using namespace std;

void myPrint(int a,int b)/* ;  错误*/
{
    cout << "普通函数调用" << endl;
}

template<typename T>
void myPrint(T a,T b)
{
    cout << "函数模版调用" << endl;
}

template<typename T>
void myPrint(T a,T b,T c)
{
    cout << "函数重载模版调用" << endl;
}


void test01()
{
    int a=10;
    int b=20;
    myPrint(a,b);
    
    //通过空模版参数列表，强制调用函数模版
    myPrint<>(a,b);
    myPrint(a,b,100);
    char ch1='a';
    char ch2='b';
    //如果函数模版产生更好的匹配，优先调用函数模版
    myPrint(ch1,ch2);
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
