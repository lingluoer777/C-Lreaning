//
//  main.cpp
//  1.1模版的基本概念1.2.1函数模版语法
//
//  Created by 翎落 on 2022/7/22.
//
//1.1模版的概念
//模版就是建立通用的模具，大大提高复用性

//模版的特点：
//模版不可以直接使用，他只是一个框架
//模版的通用并不是万能的

//1.2.1函数模版语法
//函数模版作用：
//建立一个通用函数，其函数返回值类型和形参类型可以不具体指定，用一个虚拟的类型来代表

//语法：
//template <typenmae T>
//函数声明或定义

//解释：
//template--声明创建模版
//typename--表明其后面的符号是一种数据类型，可以用class代替
//T--通用的数据类型，名称可以替换，通常为大写字母

#include <iostream>

using namespace std;

//交换两个整形函数
void Swapint(int &a,int &b)
{
    int temp=a;
    a=b;
    b=temp;
}

//交换两个浮点型函数
void Swapdouble(double &a,double &b)
{
    double temp=a;
    a=b;
    b=temp;
}

//函数模版
template<typename T>//声明一个模版，告诉编译器后面代码中的T不要报错，T是一个通用数据类型
void mySwap(T &a,T &b)
{
    T temp=a;
    a=b;
    b=temp;
}

void test01()
{
    int a=10;
    int b=20;
    //Swapint(a,b);
    
    //利用函数模版交换
    //两种方式使用函数模版
    //1、自动类型推导
    mySwap(a, b);
    cout << "a=" << a << endl;
    cout << "b=" << b << endl;
    
    double c=3.14;
    double d=5.23;
    //Swapdouble(c,d);
    
    //2、显示指定类型
    mySwap<double>(c,d);
    cout << "c=" << c << endl;
    cout << "d=" << d << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
