//
//  Person.cpp
//  1.3.7类模版分文件编写
//
//  Created by 翎落 on 2022/7/23.
//

//#include <stdio.h>
//#include "Person.h"
//

//template<typename T1,typename T2>
//Person<T1,T2>::Person(T1 name,T2 age)
//{
//    m_Name=name;
//    m_Age=age;
//}
//

//template<typename T1,typename T2>
//void Person<T1,T2>::ShowPerson()
//{
//    cout << "m_Name=" << m_Name << endl;
//    cout << "m_Age=" << m_Age << endl;
//}
