//
//  main.cpp
//  1.3.7类模版分文件编写
//
//  Created by 翎落 on 2022/7/23.
//
//问题：类模版中成员函数创建时机是在调用阶段，导致分文件编写时链接不到
//解决：
//解决方式1:直接包含.cpp源文件
//解决方式2:将声明和实现写到头一个文件中，并更改后缀名为.hpp，hpp是约定的名称，并不是强制

#include <iostream>
#include "Person.hpp"

using namespace std;

//template<typename T1,typename T2>
//class Person{
//public:
//    Person(T1 name,T2 age);
//    T1 m_Name;
//    T2 m_Age;
//    void ShowPerson();
//};
//

//template<typename T1,typename T2>
//Person<T1,T2>::Person(T1 name,T2 age)
//{
//    m_Name=name;
//    m_Age=age;
//}
//

//template<typename T1,typename T2>
//void Person<T1,T2>::ShowPerson()
//{
//    cout << "m_Name=" << m_Name << endl;
//    cout << "m_Age=" << m_Age << endl;
//}

void test01()
{
    Person<string,int>p("Tom",18);
    p.ShowPerson();
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
