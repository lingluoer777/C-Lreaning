//
//  Person.h
//  C++提高编程
//
//  Created by 翎落 on 2022/7/23.
//

#ifndef Person_h
#define Person_h

#include <iostream>

using namespace std;

template<typename T1,typename T2>
class Person{
public:
    Person(T1 name,T2 age);
    T1 m_Name;
    T2 m_Age;
    void ShowPerson();
};


template<typename T1,typename T2>
Person<T1,T2>::Person(T1 name,T2 age)
{
    m_Name=name;
    m_Age=age;
}


template<typename T1,typename T2>
void Person<T1,T2>::ShowPerson()
{
    cout << "m_Name=" << m_Name << endl;
    cout << "m_Age=" << m_Age << endl;
}


#endif /* Person_h */
