//
//  main.cpp
//  1.3.5类模版与继承
//
//  Created by 翎落 on 2022/7/23.
//
//当类模版碰到继承时，需要注意以下几点
//当子类继承的父类是一个类模版时，子类在声明的时候，要指定出父类中T的类型
//如果不指定，编译器无法给子类分配内存
//如果想灵活指定出父类中T的类型，子类也需要变为类模版

#include <iostream>

using namespace std;

template<typename T>
class Base{
public:
    T m1;
};

//class Son1:public Base//错误，必须要知道父类中的T类型，才能继承给子类
class Son1:public Base<int>{};

void test01()
{
    Son1 s1;
    s1.m1=100;
    cout << "s1.m1=" << s1.m1 << endl;
}

//如果想灵活指定父类中T类型，子类也需要变为类模版
template<typename T1,typename T2>
class Son2:public Base<T1>{
public:
    Son2()
    {
        cout << "typeid(T1)=" << typeid(T1).name() << endl;
        cout << "typeid(T2)=" << typeid(T2).name() << endl;
    }
    T2 m2;
};

void test02()
{
    Son2<int,char>s2;
    s2.m1=18;
    s2.m2='d';
    cout << "m1=" << s2.m1 << endl;
    cout << "m2=" << s2.m2 << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    test02();
    return 0;
}
