//
//  main.cpp
//  1.3.3类模版中成员函数创建时机
//
//  Created by 翎落 on 2022/7/23.
//
//类模版中成员函数和普通类中成员函数创建时机是有区别的
//普通类中的成员函数一开始就可以创建
//类模版中的成员函数在调用时才创建

#include <iostream>

using namespace std;

class Person1{
public:
    void ShowPerson1()
    {
        cout << "Show Person1" << endl;
    }
};

class Person2{
public:
    void ShowPerson2()
    {
        cout << "Show Person1" << endl;
    }
};

template<typename T>
class Person{
public:
    T obj;
    
    //类模版中的成员函数，并不是一开始就创建的，而是在模版调用时再生成
    void func1()
    {
        obj.ShowPerson1();
    }
    void func2()
    {
        obj.ShowPerson2();
    }
};

void test01()
{
    Person<Person1>p1;
    p1.func1();
    //p1.func2();//错误，说明函数在创建时才会创建成员函数
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
