//
//  main.cpp
//  1.3.9类模版案例
//
//  Created by 翎落 on 2022/7/23.
//
//实现一个通用的数组类，要求如下：
//可以对内置数据类型以及自定义数据类型的数据进行存储
//将数组中的数据存储到堆区
//构造函数中可以传入数组的容量
//提供对应的拷贝构造函数以及operater=防止浅拷贝问题
//提供尾插法和尾删法对数组中的数据进行增加和删除
//可以通过获取下标的方式访问数组中的元素
//可以获取数组中当前元素个数和数组的容量

#include <iostream>

#include "MyArray.hpp"

using namespace std;

void printIntArray(MyArray <int> &arr)
{
    for(int i=0;i<arr.getSize();i++)
    {
        cout << "arr[" << i << "]=" << arr[i] << endl;
    }
}

void test01()
{
    MyArray<int>arr1(5);
    for(int i=0;i<5;i++)
    {
        //利用尾插法向数组中插入数据
        arr1.Push_Back(i);
    }
    printIntArray(arr1);
    arr1.Pop_Back();
    printIntArray(arr1);
    cout << "arr.m_Capacity=" << arr1.getCapacity() << endl;
    cout << "arr.m_Size=" << arr1.getSize() << endl;
//    MyArray<int>arr2(arr1);
//    MyArray<int>arr3(100);
//    arr3=arr1;
}

//测试自定义数据类型
class Person{
public:
    //创建容量为5的数组时，也创建了5个类对象，即无参数也无拷贝只能调用默认拷贝函数
    Person(){}
    //当自定义有参构造时，系统不会创建默认构造函数
    Person(string name,int age)
    {
        m_Name=name;
        m_Age=age;
    }
    string m_Name;
    int m_Age;
};

void printPersonArray(MyArray <Person> &arr)
{
    for(int i=0;i<arr.getSize();i++)
    {
        cout << "arr[" << i << "].m_Name=" << arr[i].m_Name << endl;
        cout << "arr[" << i << "].m_Age=" << arr[i].m_Age << endl;
    }
}

void test02()
{
    MyArray<Person>arr2(10);
    Person p[5]={{"张三",18},{"李四",20},{"王五",36},{"赵六",58},{"五七",18}};
    for(int i=0;i<5;i++)
    {
        arr2.Push_Back(p[i]);
    }
    printPersonArray(arr2);
    arr2.Pop_Back();
    printPersonArray(arr2);
    cout << "arr.m_Capacity=" << arr2.getCapacity() << endl;
    cout << "arr.m_Size=" << arr2.getSize() << endl;
}

int main(int argc, const char * argv[]) {
    //test01();
    test02();
    return 0;
}
