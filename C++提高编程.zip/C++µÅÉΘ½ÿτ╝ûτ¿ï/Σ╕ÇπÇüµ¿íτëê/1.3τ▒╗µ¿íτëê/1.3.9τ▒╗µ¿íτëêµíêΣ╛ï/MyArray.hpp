//
//  MyArray.hpp
//  1.3.9类模版案例
//
//  Created by 翎落 on 2022/7/23.
//

#ifndef MyArray_hpp
#define MyArray_hpp

#include <stdio.h>
#include <iostream>

using namespace std;

template<typename T>
class MyArray{
public:
    //有参构造
    MyArray(int capacity)
    {
        //cout << "MyArray有参构造调用" << endl;
        m_Capacity=capacity;
        m_Size=0;
        m_Address=new T [m_Capacity];
    }
    
    //拷贝构造
    MyArray(const MyArray &arr)
    {
        //cout << "MyArray拷贝构造调用" << endl;
        m_Capacity=arr.m_Capacity;
        m_Size=arr.m_Size;
        //深拷贝
        m_Address=new T [arr.m_Size];
        //将arr中的数据都拷贝过来
        for(int i=0;i<arr.m_Size;i++)
        {
            m_Address[i]=arr.m_Address[i];
        }
    }
    
    //防止浅拷贝问题
    //拷贝构造函数是在给对象赋值用的，=运算符重载是给已有对象重新赋值时使用，使用时机不同
    MyArray& operator=(const MyArray &arr)
    {
        //cout << "operator=调用" << endl;
        //先判断原来堆区中是否有数据，如果有置为空
        if(m_Address!=nullptr)
        {
            delete [] m_Address;
            m_Address=nullptr;
            m_Capacity=0;
            m_Size=0;
        }
        m_Capacity=arr.m_Capacity;
        m_Size=arr.m_Size;
        //深拷贝
        m_Address=new T [arr.m_Size];
        for(int i=0;i<arr.m_Size;i++)
        {
            m_Address[i]=arr.m_Address[i];
        }
        return *this;
    }
    
    //尾插法
    void Push_Back(const T &val)
    {
        //判断容量是否等于大小
        if(m_Capacity==m_Size)
        {
            cout << "数组已满，无法继续插入" << endl;
            return;
        }
        m_Address[m_Size]=val;
        m_Size++;
    }
    
    //尾删法
    void Pop_Back()
    {
        //让用户访问不到最后一个元素，即为尾删，逻辑删除
        //判断大小是否等于0
        if(m_Size==0)
        {
            cout << "数组中无元素，无法继续删除" << endl;
            return;
        }
        m_Size--;
    }
    
    //通过下标方式访问数组中的元素
    T& operator[](int index)
    {
        return m_Address[index];
    }
    
    //返回数组容量
    int getCapacity()
    {
        return m_Capacity;
    }
    
    //返回数组大小
    int getSize()
    {
        return m_Size;
    }
    
    //析构函数
    ~MyArray()
    {
        //cout << "MyArray析构调用" << endl;
        delete [] m_Address;
        m_Address=nullptr;
    }
private:
    T * m_Address;//指针指向堆区开辟的真实数组
    int m_Capacity;//数组容量
    int m_Size;//数组元素个数
    
};

#endif /* MyArray_hpp */
