//
//  main.cpp
//  1.3.4类模版对象做函数参数
//
//  Created by 翎落 on 2022/7/23.
//
//类模版实例化出的对象，向函数传参的方式
//一共有三种方式：

#include <iostream>

using namespace std;

template<typename T1,typename T2>
class Person
{
public:
    Person(T1 name,T2 age)
    {
        m_Name=name;
        m_Age=age;
    }
    void ShowPerson()
    {
        cout << "m_Name=" << m_Name << endl;
        cout << "m_Age=" << m_Age << endl;
    }
    T1 m_Name;
    T2 m_Age;
};

//1、指定传入的类型  ---直接显示对象的数据类型//最常用
void printPerson01(Person<string,int>&p)
{
    p.ShowPerson();
}

void test01()
{
    Person<string,int>p1("张三",18);
    printPerson01(p1);
}

//2、参数模版化     ---将对象中的参数变为模版进行传递
template<typename T1,typename T2>
void printPerson02(Person<T1,T2>&p)
{
    p.ShowPerson();
    cout << "typeid(T1)=" << typeid(T1).name() << endl;
    cout << "typeid(T2)=" << typeid(T2).name() << endl;
}

void test02()
{
    Person<string,int>p2("李四",20);
    printPerson02(p2);
    
}
//3、整个类模版化   ---将这个对象类型模版化进行传递
template <typename T>
void printPerson03(T &p)
{
    p.ShowPerson();
    cout << "typeid(T)=" << typeid(T).name() << endl;
}

void test03()
{
    Person<string,int>p3("王五",28);
    printPerson03(p3);
}

int main(int argc, const char * argv[]) {
    //test01();
    //test02();
    test03();
    return 0;
}
