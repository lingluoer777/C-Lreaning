//
//  main.cpp
//  1.3.1类模版语法
//
//  Created by 翎落 on 2022/7/22.
//
//类模版作用：
//建立一个通用类，类中的成员 数据类型可以不具体制定，用一个虚拟的类型来代表

//语法：
//template<typename T>
//类

#include <iostream>

using namespace std;

template<typename T1,typename T2>
class Person{
public:
    Person(T1 name,T2 age)
    {
        m_Name=name;
        m_Age=age;
    }
    void Showperson()
    {
        cout << "m_Name=" << m_Name << endl;
        cout << "m_Age=" << m_Age << endl;
    }
    T1 m_Name;
    T2 m_Age;
};

int main(int argc, const char * argv[]) {
    Person<string,int>p1("张三",18);
    p1.Showperson();
    return 0;
}
