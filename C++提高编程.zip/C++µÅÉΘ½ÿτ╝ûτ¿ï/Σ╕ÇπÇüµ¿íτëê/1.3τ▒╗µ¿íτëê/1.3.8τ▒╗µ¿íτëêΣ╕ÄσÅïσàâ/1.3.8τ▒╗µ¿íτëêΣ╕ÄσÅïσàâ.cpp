//
//  main.cpp
//  1.3.8类模版与友元
//
//  Created by 翎落 on 2022/7/23.
//
//掌握类模版配合友元函数的类内和类外实现
//
//全局函数类内实现：直接在类内声明友元即可
//全局函数类外实现：需要让编译器提前知道全局函数的存在

#include <iostream>

using namespace std;

//通过全局函数打印Person信息

template<typename T1,typename T2>
class Person{
    //全局函数类内实现
    //加friend前为成员函数，加friend后为全局函数
    friend void printPerson01(Person<T1,T2>&p)
    {
        cout << "p.m_Name=" << p.m_Name << endl;
        cout << "p.m_Age=" << p.m_Age << endl;
    }

    //普通函数
    //在声明前加上模版，注意typename不要与类模版的typename重复
    template<typename T3,typename T4>
    friend void printPerson02(Person<T3,T4>&p);
public:
    Person(T1 name,T2 age);
private:
    T1 m_Name;
    T2 m_Age;
};

//全局函数类外实现
//函数模版的类外实现
template<typename T3,typename T4>
void printPerson02(Person<T3,T4>&p)
{
    cout << "p.m_Name=" << p.m_Name << endl;
    cout << "p.m_Age=" << p.m_Age << endl;
}

template<typename T1,typename T2>
Person<T1,T2>::Person(T1 name,T2 age)
{
    m_Name=name;
    m_Age=age;
}

void test01()
{
    Person<string,int>p1("Tom",18);
    printPerson01(p1);
}

void test02()
{
    Person<string,int>p2("Jerry",29);
    printPerson02(p2);
}

int main(int argc, const char * argv[]) {
    test01();
    test02();
    return 0;
}
