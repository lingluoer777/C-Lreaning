//
//  main.cpp
//  1.3.2类模版与函数模版区别
//
//  Created by 翎落 on 2022/7/23.
//

#include <iostream>

using namespace std;

template<typename T1,typename T2=int>
class Person{
public:
    Person(T1 name,T2 age)
    {
        m_Name=name;
        m_Age=age;
    }
    void Showperson()
    {
        cout << "m_Name=" << m_Name << endl;
        cout << "m_Age=" << m_Age << endl;
    }
    T1 m_Name;
    T2 m_Age;
};

//类模版没有自动类型推导的使用方式
//需要传入数据T1和T2数据类型相同才可
void test01()
{
    Person p1("张三","18");
    p1.Showperson();
    //Person p2("李四",20);//错误
    //p2.Showperson();
    Person<string,int>p3("王五",29);
    p3.Showperson();
}

//类模版在模版参数列表中可以有默认参数
void test02()
{
    Person<string>p4("赵六",28);
    p4.Showperson();
}


int main(int argc, const char * argv[]) {
    test01();
    test02();
    return 0;
}
