//
//  main.cpp
//  4.2.3二元谓词
//
//  Created by 翎落 on 2022/7/28.
//

#include <iostream>
#include <vector>

using namespace std;

class myCompare{
public:
    bool operator()(int val1,int val2)
    {
        return val1>val2;
    }
};

void test01()
{
    vector<int>v;
    v.push_back(10);
    v.push_back(30);
    v.push_back(20);
    v.push_back(50);
    v.push_back(40);
    
    sort(v.begin(), v.end());//默认为升序
    for(int i=0;i<v.size();i++)
    {
        cout << v[i] << " ";
    }
    cout << endl;
    
    //使用函数对象使排序规则为从大到小
    sort(v.begin(), v.end(),myCompare());
    for(int i=0;i<v.size();i++)
    {
        cout << v[i] << " ";
    }
    cout << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
