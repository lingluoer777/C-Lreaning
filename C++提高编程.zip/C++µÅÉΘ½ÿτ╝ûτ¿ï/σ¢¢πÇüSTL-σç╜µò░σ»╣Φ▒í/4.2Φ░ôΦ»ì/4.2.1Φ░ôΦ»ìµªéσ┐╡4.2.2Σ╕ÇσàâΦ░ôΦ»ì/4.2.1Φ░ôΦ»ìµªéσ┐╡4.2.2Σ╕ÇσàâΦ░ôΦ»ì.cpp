//
//  main.cpp
//  4.2.1谓词概念4.2.2一元谓词
//
//  Created by 翎落 on 2022/7/27.
//
//4.2.1谓词概念
//概念：
//返回bool类型的仿函数称为谓词
//如果operator()接受一个参数，叫做一元谓词
//如果operator()接受两个参数，叫做二元谓词

#include <iostream>
#include <vector>

using namespace std;

class BigThanFive{
public:
    bool operator()(int val)
    {
        return val>5;
    }
};

void test01()
{
    vector<int>v;
    for(int i=0;i<10;i++)
    {
        v.push_back(i);
    }
    
    //  查找容器中有没有大于五的数字
    vector<int>::iterator it=find_if(v.begin(), v.end(), BigThanFive()/*创建匿名对象*/);
    if(it==v.end())
        cout << "未找到" << endl;
    else
        cout << "找到了大于五的数字为：" << *it << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
