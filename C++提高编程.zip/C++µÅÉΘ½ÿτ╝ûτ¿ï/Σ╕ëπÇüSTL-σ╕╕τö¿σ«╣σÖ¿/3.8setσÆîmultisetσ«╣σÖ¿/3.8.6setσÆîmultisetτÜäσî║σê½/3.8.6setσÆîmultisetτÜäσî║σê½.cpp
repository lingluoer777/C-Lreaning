//
//  main.cpp
//  3.8.6set和multiset的区别
//
//  Created by 翎落 on 2022/7/26.
//
//set不可以插入重复数据，而multiset可以
//set插入数据的同时会返回插入结果，表示插入是否成功
//multiset不会检测数据，因此可以重复插入

#include <iostream>
#include <set>

using namespace std;

void test01()
{
    set<int>s;
    pair<set<int>::iterator, bool> ret=s.insert(10);
    if(ret.second)
        cout << "第一次插入成功" << endl;
    else
        cout << "第一次插入失败" << endl;
    
    ret=s.insert(10);
    if(ret.second)
        cout << "第二次插入成功" << endl;
    else
        cout << "第二次插入失败" << endl;
    
    
    
//    标准库类型--pair类型定义在#include <utility>头文件中，定义如下：
//
//    类模板：template<class T1,class T2> struct pair
//
//    参数：T1是第一个值的数据类型，T2是第二个值的数据类型。
//
//    功能：pair将一对值(T1和T2)组合成一个值，
//
//            这一对值可以具有不同的数据类型（T1和T2），
//
//            两个值可以分别用pair的两个公有函数first和second访问。

    
    
    multiset<int>ms;
    ms.insert(10);
    ms.insert(10);
    for(multiset<int>::const_iterator it=ms.begin();it!=ms.end();it++)
    {
        cout << *it << " ";
    }
    cout << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
