//
//  main.cpp
//  3.8.8.1set容器排序-内置数据类型
//
//  Created by 翎落 on 2022/7/26.
//
//set容器默认排序为从小到大，掌握如何改变排序规则
//利用放函数，可以改变排序规则

#include <iostream>
#include <set>

using namespace std;

class myCompare{
public:
    bool operator()(int v1,int v2)const
    {
        return v1>v2;
    }
};

//set存放自定义数据类型
void test01()
{
    set<int>s1;
    s1.insert(10);
    s1.insert(30);
    s1.insert(20);
    s1.insert(50);
    s1.insert(40);
    
    for(set<int>::iterator it=s1.begin();it!=s1.end();it++)
    {
        cout << *it << " ";
    }
    cout << endl;
    
    //指定排序规则为从大到小
    set<int,myCompare>s2;
    s2.insert(10);
    s2.insert(30);
    s2.insert(20);
    s2.insert(50);
    s2.insert(40);
    
    for(set<int>::iterator it=s2.begin();it!=s2.end();it++)
    {
        cout << *it << " ";
    }
    cout << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
