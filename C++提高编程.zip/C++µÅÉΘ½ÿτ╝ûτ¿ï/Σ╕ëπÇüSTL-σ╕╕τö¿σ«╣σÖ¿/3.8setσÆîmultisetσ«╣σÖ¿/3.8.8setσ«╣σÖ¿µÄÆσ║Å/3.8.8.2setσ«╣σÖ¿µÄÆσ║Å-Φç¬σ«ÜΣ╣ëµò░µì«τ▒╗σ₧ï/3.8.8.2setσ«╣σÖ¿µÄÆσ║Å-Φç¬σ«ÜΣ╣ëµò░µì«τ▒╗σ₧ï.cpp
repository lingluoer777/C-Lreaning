//
//  main.cpp
//  3.8.8.2set容器排序-自定义数据类型
//
//  Created by 翎落 on 2022/7/26.
//

#include <iostream>
#include <set>

using namespace std;

class Person{
public:
    Person(string name,int age)
    {
        m_Name=name;
        m_Age=age;
    }
    string m_Name;
    int m_Age;
};

class ComparePerson{
public:
    bool operator()(const Person &p1,const Person &p2)const
    {
        //按照年龄降序排列
        return p1.m_Age>p2.m_Age;
    }
};

//set存放自定义数据类型
void test01()
{
    set<Person,ComparePerson>s;
    Person p1("Tom",18);
    Person p2("Ahn",20);
    Person p3("Jane",19);
    Person p4("Joe",17);
    Person p5("Ray",21);

    //自定义数据类型，都会指定排序规则
    //set<Person>s;
    s.insert(p1);
    s.insert(p2);
    s.insert(p3);
    s.insert(p4);
    s.insert(p5);

    for(set<Person,ComparePerson>::iterator it=s.begin();it!=s.end();it++)
    {
        cout << "m_Name=" << it->m_Name << "m_Age=" << it->m_Age << endl;
    }
}


int main(int argc, const char * argv[]) {
    test01();
    return 0;
}


