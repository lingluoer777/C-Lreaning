//
//  main.cpp
//  3.8.3set大小和交换
//
//  Created by 翎落 on 2022/7/26.
//
//函数原型：
//   size();           //返回容器中元素数目

//   empty();          //判断容器是否为空

//   swap(st);         //交换两个集合容器

#include <iostream>
#include <set>

using namespace std;

void test01()
{
    set<int>s;
    s.insert(20);
    s.insert(15);
    s.insert(40);
    s.insert(30);
    s.insert(35);
    s.insert(35);
    
    if(s.empty())
        cout << "容器为空" << endl;
    else
    {
        cout << "容器不为空" << endl;
        cout << "s.size()=" << s.size() << endl;//5
    }
}

void PrintSet(const set<int>&s)
{
    for(set<int>::const_iterator it=s.begin();it!=s.end();it++)
    {
        cout << *it << " ";
    }
    cout << endl;
}

void test02()
{
    set<int>s1;
    s1.insert(20);
    s1.insert(15);
    s1.insert(40);
    s1.insert(30);
    s1.insert(35);
    s1.insert(35);
    
    set<int>s2;
    s2.insert(5);
    s2.insert(7);
    s2.insert(3);
    s2.insert(8);
    s2.insert(6);
    s2.insert(4);
    
    cout << "交换前：" << endl;
    PrintSet(s1);
    PrintSet(s2);
    
    //set中元素数目不同也可以交换
    s1.swap(s2);
    
    cout << "交换后：" << endl;
    PrintSet(s1);
    PrintSet(s2);
    
}

int main(int argc, const char * argv[]) {
    //test01();
    test02();
    return 0;
}
