//
//  main.cpp
//  3.8.4set插入和删除
//
//  Created by 翎落 on 2022/7/26.
//
//函数原型：
//   insert(elem);                //在容器中插入元素

//   clear();                     //清除所有元素

//   erase(pos);                  //清楚pos迭代器所指的元素，返回下一个元素的迭代器

//   erase(beg,end);              //删除区间[beg,end)的所有元素，返回下一个元素的迭代器

//   erase(elem);                 //删除容器中值为elem的元素

#include <iostream>
#include <set>

using namespace std;

void PrintSet(const set<int>&s)
{
    for(set<int>::const_iterator it=s.begin();it!=s.end();it++)
    {
        cout << *it << " ";
    }
    cout << endl;
}

void test01()
{
    set<int>s;
    s.insert(20);
    s.insert(10);
    s.insert(35);
    s.insert(60);
    s.insert(55);
    s.insert(70);
    s.insert(40);
    
    //set的迭代器也是双向迭代器，只支持++和--操作
    s.erase(++s.begin());
    PrintSet(s);
    
    s.erase(++s.begin(),--s.end());
    PrintSet(s);
    
    s.erase(10);
    PrintSet(s);
    
    s.clear();
    PrintSet(s);
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
