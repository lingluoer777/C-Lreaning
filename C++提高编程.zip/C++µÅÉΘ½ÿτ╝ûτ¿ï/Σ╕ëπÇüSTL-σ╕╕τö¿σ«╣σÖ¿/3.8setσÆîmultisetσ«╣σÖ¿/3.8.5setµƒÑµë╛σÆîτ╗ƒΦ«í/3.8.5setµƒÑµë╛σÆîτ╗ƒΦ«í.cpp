//
//  main.cpp
//  3.8.5set查找和统计
//
//  Created by 翎落 on 2022/7/26.
//
//函数原型：
//   find(key);         //查找key是否存在，若存在，返回该元素的迭代器，若不存在，返回set.end();

//   count(key);        //统计key的元素个数

#include <iostream>
#include <set>

using namespace std;

void test01()
{
    set<int> s;
    s.insert(20);
    s.insert(30);
    s.insert(10);
    s.insert(40);
    s.insert(15);
    
    set<int>::iterator pos=s.find(100);
    if(pos!=s.end())
        cout << *pos << endl;
    else
        cout << "未找到该元素" << endl;
    
    cout << s.count(30) << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
