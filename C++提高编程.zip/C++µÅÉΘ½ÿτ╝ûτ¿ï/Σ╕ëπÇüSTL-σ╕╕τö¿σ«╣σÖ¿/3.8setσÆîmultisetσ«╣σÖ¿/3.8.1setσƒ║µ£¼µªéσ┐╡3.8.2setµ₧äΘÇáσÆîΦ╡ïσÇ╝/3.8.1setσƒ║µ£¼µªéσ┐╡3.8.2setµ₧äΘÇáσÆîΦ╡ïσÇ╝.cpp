//
//  main.cpp
//  3.8.1set基本概念3.8.2set构造和赋值
//
//  Created by 翎落 on 2022/7/26.
//
//3.8.1set基本概念
//简介：
//所有元素都会在插入时自动排序

//本质：
//set/multiset属于关联式容器，底层结构是用二叉树实现

//set和multiset区别：
//set不允许容器中有重复的元素
//multiset允许容器中有重复的元素

//3.8.2set构造和赋值
//构造：
//   set<T> st;                            //默认构造函数

//   set(const set &st);                   //拷贝构造函数

//赋值：
//   set& operator=(const set &st);        //重载=操作符


#include <iostream>
#include <set>

using namespace std;

void PrintSet(const set<int>&s)
{
    for(set<int>::const_iterator it=s.begin();it!=s.end();it++)
    {
        cout << *it << " ";
    }
    cout << endl;
}

void test01()
{
    //插入数据，只有insert方式
    set<int>s1;
    s1.insert(30);
    s1.insert(20);
    s1.insert(40);
    s1.insert(10);
    s1.insert(20);
    
    //遍历容器
    //set容器特点：所有元素插入时自动被排序
    //set容器不允许插入重复值
    PrintSet(s1);
    
    set<int>s2(s1);
    PrintSet(s2);
    
    set<int>s3=s1;
    PrintSet(s3);
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
