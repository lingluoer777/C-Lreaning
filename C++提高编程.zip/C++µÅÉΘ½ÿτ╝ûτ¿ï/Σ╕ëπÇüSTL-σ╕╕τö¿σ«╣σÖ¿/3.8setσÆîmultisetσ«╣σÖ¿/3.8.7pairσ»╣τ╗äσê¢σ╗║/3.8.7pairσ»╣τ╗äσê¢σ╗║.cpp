//
//  main.cpp
//  3.8.7pair对组创建
//
//  Created by 翎落 on 2022/7/26.
//
//作用：
//成对出现的数据，利用对组可以返回两个数据

//两种创建方式：
//   pair<type1,type2> p (value1,value2);

//   pair<type1,type2> p=make_pair(value1,value2);

#include <iostream>

using namespace std;

void test01()
{
    pair<string, int>p("Tom",18);
    cout << "Name=" << p.first << " Age=" << p.second << endl;
    
    pair<string, int>p2=make_pair("Jerry", 17);
    cout << "Name=" << p.first << " Age=" << p.second << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
