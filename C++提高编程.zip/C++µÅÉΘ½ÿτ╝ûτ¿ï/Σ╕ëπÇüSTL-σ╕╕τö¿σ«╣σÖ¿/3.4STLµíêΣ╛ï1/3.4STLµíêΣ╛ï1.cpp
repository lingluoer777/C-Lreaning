//
//  main.cpp
//  3.4STL案例1
//
//  Created by 翎落 on 2022/7/25.
//
//案例描述：
//有五位选手ABCDE，10个评委分别对每一位选手进行打分，去除最高分和最低分，取平均分

//实现步骤：
//1、创建五名选手放到vector中
//2、遍历vector容器，取出来每一个选手，执行for循环，可以把10个评分储存到deque容器中
//3、sort算法对deque容器中分数排序，去除最高分和最低分
//4、deque容器遍历一遍，累加总分
//5、获取平均分

#include <iostream>
#include <vector>
#include <deque>
#include <ctime>

using namespace std;

class Person{
public:
    Person(string name,int ave)
    {
        m_Name=name;
        m_Ave=ave;
    }
    string m_Name;
    int m_Ave;
};

void CreatePerson(vector<Person>&v)
{
    string NameSeed="ABCDE";
    for(int i=0;i<5;i++)
    {
        string name="选手";
        name+=NameSeed[i];
        int ave=0;
        
        Person p(name,ave);
        v.push_back(p);
        
        //阶段性测试
        //cout << v[i].m_Name << "_平均分：" << v[i].m_Ave << endl;
    }
}

void Score(vector<Person>&v)
{
    //srand函数不能放在for循环内
    //随机数种子
    srand((unsigned int)time(NULL));
    for(int i=0;i<v.size();i++)
    {
        deque<int>d;
        for(int j=0;j<10;j++)
        {
            int score=rand()%41+60;
            d.push_back(score);
        }
        
        //阶段性测试
//        cout << v[i].m_Name << "打分：" << endl;
//        for(int j=0;j<10;j++)
//        {
//            cout << d[j] << " ";
//        }
//        cout << endl;
        
        //去掉最高分和最低分
        sort(d.begin(),d.end());
        d.pop_front();
        d.pop_back();
        
        //取平均分
        int sum=0;
        for(int j=0;j<d.size();j++)
        {
            sum+=d[i];
        }
        int dave=sum/d.size();
        v[i].m_Ave=dave;
    }
}

//打印平均分
void ShowAve(vector<Person>&v)
{
    for(int i=0;i<v.size();i++)
    {
        cout << v[i].m_Name << " 平均分：" << v[i].m_Ave << endl;
    }
}
    
void test01()
{
    //srand((unsigned int)time(NULL));
    vector<Person>v;
    CreatePerson(v);
    Score(v);
    ShowAve(v);
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
