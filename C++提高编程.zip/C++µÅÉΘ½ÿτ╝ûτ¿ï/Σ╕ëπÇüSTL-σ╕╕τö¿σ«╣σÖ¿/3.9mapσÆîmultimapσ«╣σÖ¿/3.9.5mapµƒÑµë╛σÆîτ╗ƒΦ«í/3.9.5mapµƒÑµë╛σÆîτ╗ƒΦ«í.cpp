//
//  main.cpp
//  3.9.5map查找和统计
//
//  Created by 翎落 on 2022/7/27.
//
//函数原型：
//   find(key);          //查找key是否存在，若存在，返回该元素的迭代器，若不存在，返回m.end()

//   count(key);         //统计key的元素个数

#include <iostream>
#include <map>

using namespace std;

void test01()
{
    map<int,int>m;
    m.insert(pair<int, int>(1,10));
    m.insert(pair<int, int>(2,20));
    m.insert(pair<int, int>(3,30));
    
    map<int,int>::iterator pos=m.find(3);
    
    if(pos!=m.end())
        cout << "找到了 key=" << pos->first << " value=" << pos->second << endl;
    else
        cout << "没找到" << pos->first << pos->second << endl;
    
    cout << m.count(3) << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
