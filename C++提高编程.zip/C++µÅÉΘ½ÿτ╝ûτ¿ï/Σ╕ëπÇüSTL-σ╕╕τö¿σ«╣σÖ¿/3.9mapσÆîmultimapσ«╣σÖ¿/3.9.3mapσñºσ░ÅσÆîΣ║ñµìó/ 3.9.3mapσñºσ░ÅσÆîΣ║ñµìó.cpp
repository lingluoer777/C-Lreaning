//
//  main.cpp
//  3.9.3map大小和交换
//
//  Created by 翎落 on 2022/7/27.
//
//函数原型：
//   size();              //返回容器中元素数目

//   empty();             //判断容器是否为空

//   swap(st);            //交换两个集合容器

#include <iostream>
#include <map>

using namespace std;

void test01()
{
    map<int,int>m;
    m.insert(pair<int, int>(1,10));
    m.insert(pair<int, int>(3,30));
    m.insert(pair<int, int>(2,20));
    m.insert(pair<int, int>(4,40));
    
    if(m.empty())
        cout << "容器为空" << endl;
    else
    {
        cout << "容器不为空" << endl;
        cout << "size()=" << m.size() << endl;
    }
}

void PrintMap(map<int,int>&m)
{
    for(map<int,int>::iterator it=m.begin();it!=m.end();it++)
    {
        cout << "key=" << it->first << " value=" << it->second << endl;
    }
    cout << endl;
}

void test02()
{
    map<int,int>m;
    m.insert(pair<int, int>(1,10));
    m.insert(pair<int, int>(3,30));
    m.insert(pair<int, int>(2,20));
    m.insert(pair<int, int>(4,40));
    
    map<int,int>m2;
    m2.insert(pair<int, int>(5,50));
    m2.insert(pair<int, int>(7,70));
    m2.insert(pair<int, int>(6,60));
    m2.insert(pair<int, int>(9,90));
    m2.insert(pair<int, int>(8,80));
    
    cout << "交换前：" << endl;
    PrintMap(m);
    PrintMap(m2);
    
    m.swap(m2);
    cout << "交换后：" << endl;
    PrintMap(m);
    PrintMap(m2);
    
    
}

int main(int argc, const char * argv[]) {
    //test01();
    test02();
    return 0;
}
