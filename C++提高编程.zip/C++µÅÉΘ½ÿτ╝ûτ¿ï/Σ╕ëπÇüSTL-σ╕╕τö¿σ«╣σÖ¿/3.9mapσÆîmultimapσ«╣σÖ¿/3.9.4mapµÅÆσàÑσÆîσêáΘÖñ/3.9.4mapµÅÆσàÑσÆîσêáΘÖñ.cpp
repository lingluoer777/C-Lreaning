//
//  main.cpp
//  3.9.4map插入和删除
//
//  Created by 翎落 on 2022/7/27.
//
//函数原型：
//   insert(elem);                 //插入元素

//   clear();                      //清空所有元素

//   erase(pos);                   //删除pos元素所指的迭代器，返回下一个元素的迭代器

//   erase(beg,end);               //删除区间[beg,end)中的所有元素，返回下一个元素的迭代器

//   erase(key);                   //删除容器中值为key的元素

#include <iostream>
#include <map>

using namespace std;

void PrintMap(map<int,int>&m)
{
    for(map<int,int>::iterator it=m.begin();it!=m.end();it++)
    {
        cout << "key=" << it->first << " value=" << it->second << endl;
    }
    cout << endl;
}

void test01()
{
    map<int,int>m;
    
    //插入
    //第一种
    m.insert(pair<int, int>(1,10));
    
    //第二种
    m.insert(make_pair(3,30));
    
    //第三种
    m.insert(map<int,int>::value_type(2,20));
    
    //第四种
    //不建议用[]插入，因为可以利用key访问到value
    m[4]=40;
    //cout << m[5] << endl;//0
    
    PrintMap(m);
    
    //删除
    m.erase(m.begin());
    PrintMap(m);
    
    m.erase(3);//按照key来删除
    PrintMap(m);
    
    m.erase(m.begin(),m.end());
    PrintMap(m);
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
