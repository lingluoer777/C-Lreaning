//
//  main.cpp
//  3.9.6map容器排序
//
//  Created by 翎落 on 2022/7/27.
//
//利用仿函数可以改变排序规则

#include <iostream>
#include <map>

using namespace std;

class Compare{
public:
    //利用仿函数降序
    bool operator()(int v1,int v2)const
    {
        return v1>v2;
    }
};

void PrintMap(const map<int,int,Compare>&m)
{
    for(map<int,int>::const_iterator it=m.begin();it!=m.end();it++)
    {
        cout << "key=" <<it->first << " value=" << it->second << endl;
    }
    cout << endl;
}

void test01()
{
    map<int,int,Compare>m;
    m.insert(pair<int, int>(1,10));
    m.insert(pair<int, int>(5,50));
    m.insert(pair<int, int>(3,30));
    m.insert(pair<int, int>(4,40));
    m.insert(pair<int, int>(2,20));
    PrintMap(m);
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}

