//
//  main.cpp
//  3.5.1stack基本概念3.5.2stack常用接口
//
//  Created by 翎落 on 2022/7/26.
//
//3.5.1stack基本概念
//栈是一种先进后出(First In Last Out,FILO)的数据结构，他只有一个出口
//栈中只有顶端的元素才可以被外界使用，因此栈不允许有遍历行为

//栈可以判断容器是否为空吗？ 可以，empty
//栈可以返回元素个数吗？ 可以，size

//3.5.2stack常用接口
//构造函数：
//   stack<T> stk;                                  //stack采用模版类实现，stack对象的默认构造形式

//   stack(const stack &stk);                       //拷贝构造函数
//通过拷贝构造的栈size=0

//赋值操作：
//   stack& operator=(const stack &stk);            //重载=操作符
//通过重载=构造的栈size=0

//数据存取：
//   push(elem);                                    //向栈顶添加一个元素

//   pop();                                         //从栈顶移出第一个元素

//   top();                                         //返回栈顶元素

//大小操作：
//   empty();                                       //判断堆栈是否为空

//   size();                                        //返回栈的大小

#include <iostream>
#include <stack>

using namespace std;

void test01()
{
    stack<int>s;
    s.push(3);
    s.push(7);
    s.push(29);
    s.push(37);
    s.push(18);
    while(!s.empty())
    {
        cout << "s.top()=" << s.top() << endl;
        cout << "s.size()=" << s.size() << endl;
        s.pop();
    }
    
    stack<int>s2(s);
    cout << s2.size() << endl;
    stack<int>s3;
    s3=s;
    cout << s3.size() << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
