//
//  main.cpp
//  3.1.3string赋值操作
//
//  Created by 翎落 on 2022/7/24.
//
//作用：
//给strig字符串进行赋值

//赋值的函数原型
//string& operator=(const char* s);           //char*类型的字符出啊赋值给当前字符串

//string& operator=(const string &s);         //把字符串s赋给当前字符串

//string& operator=(char c);                  //字符赋值给当前的字符串

//string& assign(const char *s);              //把字符串s赋给当前字符串

//string& assign(const char *s,int n);        //把字符串s的前n个字符赋给当前的字符串

//string& assign(const string &s);            //把字符串s赋给当前的字符串

//string& assign(int n,char c);               //用n个字符c赋给当前字符串

#include <iostream>
#include <string>

using namespace std;

void test01()
{
    string s1;
    s1="hellow world";
    cout << "s1=" << s1 << endl;
    
    string s2;
    s2=s1;
    cout << "s2=" << s2 << endl;
    
    string s3;
    s3='c';
    cout << "s3=" << s3 << endl;
    
    string s4;
    s4.assign("hellow world");
    cout << "s4=" << s4 << endl;
    
    string s5;
    s5.assign("hello world",7);
    cout << "s5=" << s5 << endl;
    
    string s6;
    s6.assign(s5);
    cout << "s6=" << s6 << endl;
    
    string s7;
    s7.assign(10,'w');
    cout << "s7=" << s7 << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
