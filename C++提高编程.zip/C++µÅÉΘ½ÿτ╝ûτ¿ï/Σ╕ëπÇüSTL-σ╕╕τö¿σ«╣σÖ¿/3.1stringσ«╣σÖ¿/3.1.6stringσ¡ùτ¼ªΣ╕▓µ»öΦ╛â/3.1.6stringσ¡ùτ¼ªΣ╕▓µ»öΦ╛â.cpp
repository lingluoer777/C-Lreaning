//
//  main.cpp
//  3.1.6string字符串比较
//
//  Created by 翎落 on 2022/7/24.
//
//功能描述：字符串之间的比较

//比较方式：字符串比较是按字符的ASCII码进行对比
//   = 返回0
//   > 返回1
//   < 返回-1

//函数原型
//   int compare(const string &s)const;     //与字符串s比较

//   int conpare(const char* s)const;       //与字符串s比较

#include <iostream>
#include <string>

using namespace std;

void test01()
{
    string str1="kello";
    string str2="hello";
    int ret=str1.compare(str2);
    cout << "ret=" << ret << endl;
    if(ret==0)
        cout << "str1=str2" << endl;
    else if(ret>0)
        cout << "str1>str2" << endl;
    else
        cout << "str1<str2" << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
