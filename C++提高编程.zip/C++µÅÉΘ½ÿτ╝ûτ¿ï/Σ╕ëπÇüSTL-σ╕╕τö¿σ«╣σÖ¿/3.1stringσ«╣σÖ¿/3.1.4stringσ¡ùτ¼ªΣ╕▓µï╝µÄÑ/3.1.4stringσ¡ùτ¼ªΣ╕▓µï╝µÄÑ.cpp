//
//  main.cpp
//  3.1.4string字符串拼接
//
//  Created by 翎落 on 2022/7/24.
//
//作用：
//实现在字符串末尾拼接字符串

//函数原型
//string& operator+=(const char* str);                    //重载+=运算符

//string& operator+=(const char c);                       //重载+=运算符

//string& operator+=(const string& str);                  //重载+=运算符

//string& append(const char *s);                          //把字符串s连接到当前字符串末尾

//string& append(const char *s,int n);                    //把字符串s的前n个字符连接到当前字符串末尾

//string& append(const string &s);                        //同string& operator+=(const string& str);

//string& append(const string &s,int pos,int n);          //把字符串从pos开始的n个字符连接到字符串结尾

#include <iostream>
#include <string>

using namespace std;

void test01()
{
    string s1="hello";
    s1+="world";
    cout << "s1=" << s1 << endl;
    
    s1+='s';
    cout << "s1=" << s1 << endl;
    
    string s2="askldhjf";
    s1+=s2;
    cout << "s1=" << s1 << endl;
    
    string s3="skdk";
    s3.append("kj");
    cout << "s3=" << s3 << endl;
    
    s3.append("shfjfjf",3);
    cout << "s3=" << s3 << endl;
    
    s3.append(s2);
    cout << "s3=" << s3 << endl;
    
    //pos：从哪个位置开始截取
    //n：截取字符个数
    s3.append(s2,3,4);
    cout << "s3=" << s3 << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
