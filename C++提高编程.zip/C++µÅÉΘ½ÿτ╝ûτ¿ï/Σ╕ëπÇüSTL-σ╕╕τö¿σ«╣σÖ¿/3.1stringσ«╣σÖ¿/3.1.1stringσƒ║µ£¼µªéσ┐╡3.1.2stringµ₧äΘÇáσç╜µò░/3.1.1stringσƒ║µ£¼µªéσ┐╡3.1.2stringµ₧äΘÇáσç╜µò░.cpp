//
//  main.cpp
//  3.1.1string基本概念3.1.2string构造函数
//
//  Created by 翎落 on 2022/7/24.
//
//3.1.1string基本概念
//本质：
//string是C++风格的字符串，而string本身是一个类

//string和char *的区别
//char *是一个指针
//string是一个类，类内部封装了char*，管理这个字符串，是一个char*型的容器

//特点
//string类内部封装了很多成员方法
//string管理char*所分配的内存，不用担心复制越界和取值越界等，由类内部进行负责

//3.1.2string构造函数

//构造函数原型：
//string();                      //创建一个空的字符串，如：string str;

//string(const char* s);         //使字符串s初始化

//string(const string& str);     //使一个字符串对象初始化另一个字符串对象

//string(int n,char c);          //使n个字符c初始化

#include <iostream>
#include <string>

using namespace std;

void test01()
{
    string s1;
    const char* str="hello world";
    string s2(str);
    cout << "s2=" << s2 << endl;
    string s3(s2);
    cout << "s3=" << s3 << endl;
    string s4(10,'c');
    cout << "s4=" << s4 << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
