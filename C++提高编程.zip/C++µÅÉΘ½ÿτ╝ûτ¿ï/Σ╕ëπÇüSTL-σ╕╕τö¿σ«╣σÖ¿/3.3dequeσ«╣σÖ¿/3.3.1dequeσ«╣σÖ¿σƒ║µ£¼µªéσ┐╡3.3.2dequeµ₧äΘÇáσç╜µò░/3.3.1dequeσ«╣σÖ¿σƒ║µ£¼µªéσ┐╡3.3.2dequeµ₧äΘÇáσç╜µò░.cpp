//
//  main.cpp
//  3.3.1deque容器基本概念3.3.2deque构造函数
//
//  Created by 翎落 on 2022/7/25.
//
//3.3.1deque容器基本概念
//作用：
//双端数组，可以对头端进行插入和删除操作

//deque与vector区别：
//vector对于头部的插入删除效率低，数据量越大，效率越低
//deque相对而言，对头部的插入删除速度比vector快
//vector访问内部元素时的速度比deque快，这与两者的内部实现有关

//                                    front()                 back()
//                                  __________________________________
//        push_front()------------>   ______________________________   <-------push_back()
//                                    |_____|_____|_____|_____|_____|
//         pop_front()<------------ __________________________________ -------->pop_back()
//                                       |        ___|___                |
//                                       |        |__5__|                |
//                                     begin()    insert()             end()

//deque内部工作原理：
//deque内部有个中控器，维护每段缓冲区中的内容，缓冲区存放真实数据
//中控器维护的是每个缓冲区的地址，使得使用deque时像一片连续的内存空间

//         中控器
//        |      |                     缓冲区
//        |      |       ____________________________________
//    节点 | 0x01 | ----->__________________|_ele_|_ele_|_ele_|
//        | 0x02 | ----->|_ele_|_ele_|_ele_|_ele_|_ele_|_ele_|
//        | 0x03 | ----->|_ele_|_ele_|_ele_|_________________|
//        |      |

//deque容器的迭代器也是支持随机访问的

//3.3.2deque构造函数

//函数原型：
//   deque<T>deqT;                       //默认构造形式

//   deque(beg,end);                     //构造函数将[begin,end)区间中的元素拷贝给本身

//   deque(n,elem);                      //构造函数将n个elem拷贝给本身

//   deque(const deque &deq);            //拷贝构造函数

#include <iostream>
#include <deque>

using namespace std;

//加入const使变为只读，防止误改数据
void PrintDeque(const deque<int>&d)
{
    for(deque<int>::const_iterator it=d.begin();it!=d.end();it++)
    {
        //*it=100//错误
        cout << *it << " ";
    }
    cout << endl;
}

void test01()
{
    deque<int>d1;
    for(int i=0;i<10;i++)
    {
        d1.push_back(i+1);
    }
    PrintDeque(d1);
    
    deque<int>d2(d1.begin(),d1.end());
    PrintDeque(d2);
    
    deque<int>d3(10,34);
    PrintDeque(d3);
    
    deque<int>d4(d3);
    PrintDeque(d4);
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
