//
//  main.cpp
//  3.3.3deque赋值操作
//
//  Created by 翎落 on 2022/7/25.
//
//函数原型：
//   deque& opeartor=(const deque &deq);         //重载=操作符

//   assign(beg,end);                            //将[beg,end)区间中的元素拷贝赋值给本身

//   assign(n,elem);                             //将n个elem拷贝赋值给本身

#include <iostream>
#include <deque>

using namespace std;

void myPrint(int &val)
{
    cout << val << " ";
}

void PrintDeque(deque<int>&deq)
{
    for_each(deq.begin(), deq.end(), myPrint);
    cout << endl;
}

void test01()
{
    deque<int>d1;
    for(int i=0;i<10;i++)
    {
        d1.push_back(i+1);
    }
    PrintDeque(d1);
    
    deque<int>d2;
    d2=d1;
    PrintDeque(d2);
    
    deque<int>d3;
    d3.assign(d1.begin(),d1.end());
    PrintDeque(d3);
    
    deque<int>d4;
    d4.assign(10,34);
    PrintDeque(d4);
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
