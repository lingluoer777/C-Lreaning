//
//  main.cpp
//  3.3.5deque插入和删除
//
//  Created by 翎落 on 2022/7/25.
//
//函数原型：
//两段插入操作：
//push_back(elem);              //在容器尾部添加一个数据

//push_front(elem);             //在容器头部添加一个数据

//pop_back();                   //删除容器最后一个数据

//pop_front();                  //删除容器第一个数据
//指定位置操作：
//insert(pos,elem);             //在pos位置插入一个elem元素的拷贝，返回新元素的位置

//insert(pos,n,elem);           //在pos位置插入n个elem数据，无返回值

//insert(pos,beg,end);          //在pos位置插入[beg,end)区间的数据，无返回值

//clear();                     //清空容器的所有位置

//erase(beg,end);               //删除[beg,end)区间的数据，返回下一个元素的位置

//erase(pos);                   //删除pos位置的数据，返回下一个数据的位置
 
#include <iostream>
#include <deque>

using namespace std;

void myPrint(int &val)
{
    cout << val << " ";
}

void PrintDeque(deque<int>&deq)
{
    for_each(deq.begin(), deq.end(), myPrint);
    cout << endl;
}

void test01()
{
    deque<int>d;
    d.push_back(3);
    d.push_back(6);
    d.push_back(8);
    d.push_front(2);
    d.push_front(17);
    PrintDeque(d);
    
    d.pop_back();
    d.pop_front();
    PrintDeque(d);
}

void test02()
{
    deque<int>d1;
    d1.push_back(3);
    d1.push_back(6);
    d1.push_back(8);
    d1.push_front(2);
    d1.push_front(17);
    PrintDeque(d1);
    
    d1.insert(d1.begin()+2, 35);
    PrintDeque(d1);
    
    d1.insert(d1.begin()+3, 3,17);
    PrintDeque(d1);
    
    deque<int>d2;
    d2.push_back(1);
    d2.push_back(4);
    d2.push_back(6);
    d2.push_back(5);
    d2.push_back(11);
    
    d1.insert(d1.begin()+1, d2.begin()+1,d2.begin()+3);
    PrintDeque(d1);
    
    d1.erase(d1.begin()+6);
    PrintDeque(d1);
    
    d1.erase(d1.begin()+4,d1.begin()+7);
    PrintDeque(d1);
    
    d1.clear();
    PrintDeque(d1);
}

int main(int argc, const char * argv[]) {
    //test01();
    test02();
    return 0;
}
