//
//  main.cpp
//  3.3.4deque大小操作
//
//  Created by 翎落 on 2022/7/25.
//
//作用：
//对deque容器的大小进行操作

//函数原型：
//   deque.empty();                     //判断容器是否为空

//   deque.size();                      //返回容器中元素个数

//   deque.resize(num);                 //重新指定容器的常度为num，若容器变长，则以默认值填充新位置，若容器变短，则末尾超出容器长度的元素被删除

//   deque.resize(num,elem);            //重新指定容器的常度为num，若容器变长，则以elem值填充新位置，若容器变短，则末尾超出容器长度的元素被删除

#include <iostream>
#include <deque>

using namespace std;

void myPrint(int &val)
{
    cout << val << " ";
}

void PrintDeque(deque<int>&deq)
{
    for_each(deq.begin(), deq.end(), myPrint);
    cout << endl;
}

void test01()
{
    deque<int>d;
    for(int i=0;i<10;i++)
    {
        d.push_back(i+3);
    }
    PrintDeque(d);
    
    if(d.empty())
        cout << "deque为空" << endl;
    else
    {
        cout << "deque不为空" << endl;
        cout << "deque.size()=" << d.size() << endl;
        //deque中没有capacity概念
    }
    
    d.resize(15,3);
    PrintDeque(d);
    
    d.resize(5);
    PrintDeque(d);
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
