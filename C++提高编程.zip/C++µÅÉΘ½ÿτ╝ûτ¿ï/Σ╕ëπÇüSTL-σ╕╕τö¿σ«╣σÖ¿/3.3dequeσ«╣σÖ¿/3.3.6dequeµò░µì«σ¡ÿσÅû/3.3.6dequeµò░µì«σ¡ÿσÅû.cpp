//
//  main.cpp
//  3.3.6deque数据存取
//
//  Created by 翎落 on 2022/7/25.
//
//函数原型：
//   at(int idx);          //返回索引idx所指的数据

//   operator[];           //返回索引idx所指的数据

//   front();              //返回容器中第一个数据元素

//   back();               //返回容器中最后一个数据元素

#include <iostream>
#include <deque>

using namespace std;

void test01()
{
    deque<int>d;
    for(int i=0;i<5;i++)
    {
        d.push_back(2*i+1);
    }
    for(int i=0;i<d.size();i++)
    {
        cout << d.at(i) << " ";
    }
    cout << endl;
    
    for(int i=0;i<d.size();i++)
    {
        cout << d[i] << " ";
    }
    cout << endl;
    
    cout << "d.front()=" << d.front() << endl;
    cout << "d.back()=" << d.back() << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
