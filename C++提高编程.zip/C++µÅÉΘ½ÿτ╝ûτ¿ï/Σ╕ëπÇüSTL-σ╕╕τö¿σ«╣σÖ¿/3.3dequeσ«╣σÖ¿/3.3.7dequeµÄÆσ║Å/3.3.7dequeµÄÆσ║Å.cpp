//
//  main.cpp
//  3.3.7deque排序
//
//  Created by 翎落 on 2022/7/25.
//
//作用：
//利用算法实现对deque容器进行排序

//函数原型：
//   sort(iterator beg,iterator end);      //对[beg,end)区间内的元素进行排序
//要#include <algorithm>
#include <iostream>
#include <deque>

using namespace std;

void PrintDeque(deque<int>&d)
{
    for(int i=0;i<d.size();i++)
    {
        cout << d[i] << " ";
    }
    cout << endl;
}

void test01()
{
    deque<int>d;
    d.push_back(5);
    d.push_back(7);
    d.push_back(1);
    d.push_back(6);
    d.push_front(26);
    d.push_front(58);
    d.push_front(19);
    PrintDeque(d);
    
    //排序默认为升序排序
    //对于支持随机访问迭代器的容器，都可以利用sort算法直接对其进行排序
    //vector容器也可以利用sort进行排序
    sort(d.begin()+2,d.begin()+6);
    PrintDeque(d);
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
