//
//  main.cpp
//  3.2.6vector数据存取
//
//  Created by 翎落 on 2022/7/25.
//
//函数原型：
//   at(int idx);         //返回索引idx指向的数据

//   operator[];          //返回索引idx指向的数据

//   front();             //返回容器中第一个数据元素

//   back();              //返回容器中最后一个数据元素

#include <iostream>
#include <vector>

using namespace std;

void test01()
{
    vector<int>v;
    for(int i=0;i<10;i++)
    {
        v.push_back(i+3);
    }
    //利用[]方式访问vector中元素
    for(int i=0;i<v.size();i++)
    {
        cout << v.at(i) << " ";
    }
    cout << endl;
    
    //利用at方式访问元素
    for(int i=0;i<v.size();i++)
    {
        cout << v[i] << " ";
    }
    cout << endl;
    
    //访问第一个元素
    cout << "v.front=" << v.front() << endl;
    
    //访问最后一个元素
    cout << "v.back=" << v.back() << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
