//
//  main.cpp
//  3.2.7vector互换容器
//
//  Created by 翎落 on 2022/7/25.
//
//作用：
//实现两个容器内元素进行互换

//函数原型
//swap(vec);     //将vec与本身的元素互换//vec的数据类型要与本身数据类型相同，否则报错

#include <iostream>
#include <vector>

using namespace std;

void PrintVector(vector<int>&v)
{
    for(int i=0;i<v.size();i++)
    {
        cout << v[i] << " ";
    }
    cout << endl;
}

void test01()
{
    vector<int>v1;
    for(int i=0;i<10;i++)
    {
        v1.push_back(i+1);
    }
    cout << "交换前：" << endl;
    PrintVector(v1);
    vector<int>v2;
    for(int i=0;i<3;i++)
    {
        v2.push_back(2*i);
    }
    PrintVector(v2);
    cout << "交换后：" << endl;
    v1.swap(v2);
    PrintVector(v1);
    PrintVector(v2);
}

//2、实际用途
//使用swap收缩内存
void test02()
{
    vector<int>v;
    for(int i=0;i<150000;i++)
    {
        v.push_back(i+5);
    }
    cout << "v.capacity=" << v.capacity() << endl;
    cout << "v.size=" << v.size() << endl;
    v.resize(15);
    cout << "v.capacity=" << v.capacity() << endl;//resize后vector的capacity不变，size改变
    cout << "v.size=" << v.size() << endl;
    //利用swap收缩内存
    vector<int>(v).swap(v);
    //vector<int>(v):利用拷贝构造函数初始化一个匿名对象，匿名对象的capacity和size都为15
    //swap(v):类似于指针的交换，v和匿名对象指向的内存互换
    //匿名对象该行语句结束后内存即被回收，所以可以节省内存
    cout << "v.capacity=" << v.capacity() << endl;
    cout << "v.size=" << v.size() << endl;
}

int main(int argc, const char * argv[]) {
    //test01();
    test02();
    return 0;
}
