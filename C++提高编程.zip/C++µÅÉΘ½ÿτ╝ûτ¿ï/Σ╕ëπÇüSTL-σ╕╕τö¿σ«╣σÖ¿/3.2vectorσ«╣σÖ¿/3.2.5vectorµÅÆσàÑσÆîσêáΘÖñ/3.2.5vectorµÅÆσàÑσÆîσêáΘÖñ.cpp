//
//  main.cpp
//  3.2.5vector插入和删除
//
//  Created by 翎落 on 2022/7/25.
//
//函数原型：
//   push_back(ele);                                           //尾部插入元素ele

//   pop_back();                                               //删除最后一个元素

//   insert(const_iterator pos,ele);                           //迭代器指向位置pos插入元素ele

//   insert(const_iterator pos,int count,ele);                 //迭代器指向位置pos插入count个ele

//   erase(const_iterator pos);                                //删除迭代器指向的位置

//   erase(const_iterator pos,const_iterator end);             //删除迭代器从start到end之间的元素

//   clear();                                                  //删除容器中所有元素
 
#include <iostream>
#include <vector>

using namespace std;

void myPrint(int val)
{
    cout << val << " ";
}

void PrintVector(vector<int>&v)
{
    for_each(v.begin(), v.end(), myPrint);
    cout << endl;
}

void test01()
{
    vector<int>v;
    for(int i=0;i<10;i++)
    {
        v.push_back(2*i+3);
    }
    //遍历
    PrintVector(v);
    
    v.push_back(28);
    PrintVector(v);
    
    v.pop_back();
    PrintVector(v);
    
    //插入，第一个参数为迭代器
    v.insert(v.begin()+3,19);
    PrintVector(v);
    
    v.insert(v.begin()+5, 3,27);
    PrintVector(v);
    
    //删除，参数也是迭代器
    v.erase(v.begin()+6);
    PrintVector(v);
    
    v.erase(v.begin()+2,v.begin()+8);
    PrintVector(v);
    
    v.clear();//等价于v.erase(v.begin(),v.end());
    PrintVector(v);
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
