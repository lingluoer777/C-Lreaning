//
//  main.cpp
//  3.2.3vector赋值操作
//
//  Created by 翎落 on 2022/7/24.
//
//作用：
//给vector容器进行赋值

//函数原型
//vector& operator=(const vector &vec);     //重载=操作符

//assign(beg,end);                          //将[beg,end)区间中的数据拷贝赋值给本身

//assign(n,elem);                           //将n个elem拷贝赋值给本身

#include <iostream>
#include <vector>

using namespace std;

void myPrint(int val)
{
    cout << val << " ";
}

void PrintVector(vector<int>&v)
{
    for_each(v.begin(), v.end(), myPrint);
    cout << endl;
}

void test01()
{
    //vector赋值
    vector<int>v1;
    for(int i=0;i<9;i++)
    {
        v1.push_back(i+1);
    }
    PrintVector(v1);
    
    //赋值，operator=
    vector<int>v2=v1;
    PrintVector(v2);
    
    //assign
    vector<int>v3;
    v3.assign(v1.begin(), v1.end());
    PrintVector(v3);
    
    //n个elem方式赋值
    vector<int>v4;
    v4.assign(10, 39);
    PrintVector(v4);
    
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}

