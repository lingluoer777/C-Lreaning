//
//  main.cpp
//  3.10STL案例2
//
//  Created by 翎落 on 2022/7/27.
//

#include <iostream>
#include <vector>
#include <map>
#include <ctime>

#define CEHUA 0
#define MEISHU 1
#define YANFA 2

using namespace std;

class Employee{
public:
    string m_Name;
    int m_Salary;
};

//在vector中添加员工
void PushEmployee(vector<Employee>&v)
{

    string NameSeed="ABCDEFGHIJ";
    for(int i=0;i<10;i++)
    {
        Employee e;
        e.m_Name="员工";
        e.m_Name+=NameSeed[i];
        e.m_Salary=rand()%4000+6000;
        v.push_back(e);
    }
}

//在multimap中添加员工信息
void InsertInf(vector<Employee>&v,multimap<int,Employee>&m)
{
    for(int i=0;i<v.size();i++)
    {
        m.insert(pair<int, Employee>(rand()%3,v[i]));
    }
}

//遍历multimap分组打印员工信息
void PrintInf(multimap<int,Employee>&m)
{
    //策划部门
    cout << "策划部门：" << endl;
    multimap<int,Employee>::iterator pos=m.find(CEHUA);
    unsigned long count=m.count(CEHUA);
    int index=0;
    for(;index<count;pos++,index++)
    {
            cout << "员工姓名：" << pos->second.m_Name << " \t员工工资：" << pos->second.m_Salary << endl;
    }
    cout << endl;

    //美术部门
    cout << "美术部门：" << endl;
    pos=m.find(MEISHU);
    count=m.count(MEISHU);
    index=0;
    for(;index<count;pos++,index++)
    {
            cout << "员工姓名：" << pos->second.m_Name << " \t员工工资：" << pos->second.m_Salary << endl;
    }
    cout << endl;

    //研发部门
    cout << "研发部门：" << endl;
    pos=m.find(YANFA);
    count=m.count(YANFA);
    index=0;
    for(;index<count;pos++,index++)
    {
            cout << "员工姓名：" << pos->second.m_Name << " \t员工工资：" << pos->second.m_Salary << endl;
    }
    cout << endl;
}

void test01()
{
    srand((unsigned int)time(NULL));
    vector<Employee>v;
    PushEmployee(v);
    
    //阶段测试，遍历vector容器
//    for(vector<Employee>::iterator it=v.begin();it!=v.end();it++)
//    {
//        cout << "m_Name=" << it->m_Name << " m_Salary=" << it->m_Salary << endl;
//    }
//    cout << endl;
    
    multimap<int,Employee>m;
    InsertInf(v,m);
    PrintInf(m);
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
