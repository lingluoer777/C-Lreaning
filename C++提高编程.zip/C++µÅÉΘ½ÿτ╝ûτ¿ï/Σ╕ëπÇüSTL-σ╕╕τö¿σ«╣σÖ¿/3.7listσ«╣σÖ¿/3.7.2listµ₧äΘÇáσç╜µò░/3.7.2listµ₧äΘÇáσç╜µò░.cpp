//
//  main.cpp
//  3.7.2list构造函数
//
//  Created by 翎落 on 2022/7/26.
//
//函数原型：
//   list<T> lst;                       //list采用模版类实现，采用对象的默认构造形式

//   list(beg,end);                     //构造函数将[beg,end)区间中的元素拷贝给本身

//   list(n,elem);                      //构造函数将n个elem拷贝给本身
//第二种和第三种都相当于有参构造

//   list(const list &lst);             //拷贝构造函数

#include <iostream>
#include <list>

using namespace std;

void myPrint(int &val)
{
    cout << val << " ";
}

void PrintList(list<int>&l)
{
    for_each(l.begin(), l.end(), myPrint);
    cout << endl;
}

void test01()
{
    list<int>L1;
    L1.push_back(34);
    L1.push_back(23);
    L1.push_back(11);
    L1.push_back(89);
    L1.push_back(17);
    PrintList(L1);
    
    list<int>L2(L1.begin(),L1.end());
    PrintList(L2);
    
    list<int>L3(10,37);
    PrintList(L3);
    
    list<int>L4(L1);
    PrintList(L4);
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
