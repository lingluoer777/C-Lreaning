//
//  main.cpp
//  3.7.4list大小操作
//
//  Created by 翎落 on 2022/7/26.
//
//函数原型：
//   empty();                     //判断容器是否为空

//   size();                      //返回容器中元素个数

//   resize(num);                 //重新指定容器的常度为num，若容器变长，则以默认值填充新位置，若容器变短，则末尾超出容器长度的元素被删除

//   resize(num,elem);            //重新指定容器的常度为num，若容器变长，则以elem值填充新位置，若容器变短，则末尾超出容器长度的元素被删除

#include <iostream>
#include <list>

using namespace std;

void myPrint(int &val)
{
    cout << val << " ";
}

void PrintList(list<int>&l)
{
    for_each(l.begin(), l.end(), myPrint);
    cout << endl;
}

void test01()
{
    list<int>L1;
    L1.push_back(20);
    L1.push_back(30);
    L1.push_back(40);
    L1.push_back(50);
    L1.push_back(10);
    PrintList(L1);
    
    if(L1.empty())
        cout << "list为空" << endl;
    else
    {
        cout << "list不为空" << endl;
        cout << "L1.size()=" << L1.size() << endl;
    }
    
    L1.resize(10,23);
    PrintList(L1);
    
    L1.resize(3);
    PrintList(L1);
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
