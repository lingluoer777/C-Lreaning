//
//  main.cpp
//  3.7.6list数据存取
//
//  Created by 翎落 on 2022/7/26.
//
//函数原型：
//   front();     //返回第一个元素

//   back();      //返回最后一个元素

#include <iostream>
#include <list>

using namespace std;

void test01()
{
    list<int>L;
    L.push_back(10);
    L.push_back(20);
    L.push_back(30);
    L.push_back(40);
    L.push_back(50);
    
    cout << "L.front()=" << L.front() << endl;
    cout << "L.end()=" << L.back() << endl;
    
    //L[0];//错误，不能用[]访问list中的元素
    //L.at(0);//错误，不能用at方式访问list中的元素
    
    //原因是list不采用连续空间进行存储，迭代器也是不支持随机访问的
    
    list<int>::iterator it=L.begin();
    it++;
    it--;
    //支持双向移动
    //it=it+1;//错误，不支持随机访问
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
