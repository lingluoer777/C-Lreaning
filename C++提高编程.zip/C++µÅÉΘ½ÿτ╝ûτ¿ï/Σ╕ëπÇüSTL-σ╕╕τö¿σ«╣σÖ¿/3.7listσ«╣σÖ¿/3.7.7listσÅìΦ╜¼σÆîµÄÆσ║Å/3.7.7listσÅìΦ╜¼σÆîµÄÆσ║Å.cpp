//
//  main.cpp
//  3.7.7list反转和排序
//
//  Created by 翎落 on 2022/7/26.
//
//函数原型：
//   reverse();         //反转链表

//   sort();            //链表排序

#include <iostream>
#include <list>

using namespace std;

void PrintList(list<int>&L)
{
    for(list<int>::iterator it=L.begin();it!=L.end();it++)
    {
        cout << *it << " ";
    }
    cout << endl;
}

bool myCompare(int v1,int v2)
{
    //降序，就让第一个数>第二个数
    return v1>v2;
}

void test01()
{
    list<int>L;
    L.push_back(3);
    L.push_back(1);
    L.push_back(5);
    L.push_back(4);
    L.push_back(7);
    PrintList(L);
    
    L.reverse();
    cout << "反转后：" << endl;
    PrintList(L);
    
    //所有不支持随机访问迭代器的容器，不可以用标准算法
    //不支持随机访问迭代器的容器，容器内部会提供一些对应算法
    //sort(L.begin(),L.end());//错误
    //全局函数
    
    L.sort();//默认排序为从小到大
    //成员函数
    cout << "排序后：" << endl;
    PrintList(L);
    
    //降序
    L.sort(myCompare);
    PrintList(L);
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
