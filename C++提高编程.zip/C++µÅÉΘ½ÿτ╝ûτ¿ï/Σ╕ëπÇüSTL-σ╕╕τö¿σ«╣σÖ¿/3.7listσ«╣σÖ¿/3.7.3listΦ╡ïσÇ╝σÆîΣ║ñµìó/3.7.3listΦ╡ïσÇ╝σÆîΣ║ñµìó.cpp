//
//  main.cpp
//  3.7.3list赋值和交换
//
//  Created by 翎落 on 2022/7/26.
//
//作用：
//给list容器进行赋值，以及交换list容器

//函数原型：
//   assign(beg,end);                            //将[beg,end)区间中的数据拷贝赋值给本身
//list是双向迭代器，不能跳跃移动

//   assign(n,elem);                             //将n个elem拷贝赋值给本身

//   list& operator=(const list &lst);           //重载=操作符

//   swap(lst);                                  //将lst与本身的元素互换

#include <iostream>
#include <list>

using namespace std;

void myPrint(int &val)
{
    cout << val << " ";
}

void PrintList(list<int>&l)
{
    for_each(l.begin(), l.end(), myPrint);
    cout << endl;
}

void test01()
{
    list<int>L1;
    L1.push_back(20);
    L1.push_back(30);
    L1.push_back(40);
    L1.push_back(50);
    L1.push_back(10);
    PrintList(L1);
    
    list<int>L2;
    L2.assign(L1.begin(),L1.end());
    PrintList(L2);
    
    list<int>L3;
    L3.assign(10,37);
    PrintList(L3);
    
    list<int>L4;
    L4=L2;
    PrintList(L2);
}

void test02()
{
    list<int>L1;
    L1.push_back(20);
    L1.push_back(30);
    L1.push_back(40);
    L1.push_back(50);
    L1.push_back(10);
    list<int>L2;
    L2.assign(10,37);
    cout << "交换前：" << endl;
    PrintList(L1);
    PrintList(L2);
    cout << "交换后：" << endl;
    L1.swap(L2);
    PrintList(L1);
    PrintList(L2);
}

int main(int argc, const char * argv[]) {
    //test01();
    test02();
    return 0;
}
