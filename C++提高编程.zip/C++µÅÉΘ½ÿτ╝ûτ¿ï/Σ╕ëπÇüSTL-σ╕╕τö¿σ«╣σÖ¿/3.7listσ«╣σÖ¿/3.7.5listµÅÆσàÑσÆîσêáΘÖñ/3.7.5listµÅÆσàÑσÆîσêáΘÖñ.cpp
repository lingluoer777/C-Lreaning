//
//  main.cpp
//  3.7.5list插入和删除
//
//  Created by 翎落 on 2022/7/26.
//
//函数原型：
//push_back(elem);              //在容器尾部添加一个数据

//push_front(elem);             //在容器头部添加一个数据

//pop_back();                   //删除容器最后一个数据

//pop_front();                  //删除容器第一个数据

//insert(pos,elem);             //在pos位置插入一个elem元素的拷贝，返回新元素的位置

//insert(pos,n,elem);           //在pos位置插入n个elem数据，无返回值

//insert(pos,beg,end);          //在pos位置插入[beg,end)区间的数据，无返回值

//clear();                      //清空容器的所有位置

//erase(beg,end);               //删除[beg,end)区间的数据，返回下一个元素的位置

//erase(pos);                   //删除pos位置的数据，返回下一个数据的位置

//remove(elem);                 //删除容器中所有与elem值匹配的元素

#include <iostream>
#include <list>

using namespace std;

void myPrint(int &val)
{
    cout << val << " ";
}

void PrintList(list<int>&L)
{
    for_each(L.begin(), L.end(), myPrint);
    cout << endl;
}

void test01()
{
    list<int>L;
    L.push_back(23);
    L.push_back(4);
    L.push_back(6);
    L.push_front(34);
    L.push_front(17);
    L.push_front(9);
    L.push_front(2);
    PrintList(L);
    
    L.pop_front();
    L.pop_back();
    PrintList(L);
    
    //list中的++经过重载
    L.insert(++L.begin(), 5,18);
    PrintList(L);
    
    L.erase(++(++L.begin()));
    PrintList(L);
    
    L.remove(18);
    PrintList(L);
    
    L.clear();
    PrintList(L);
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
