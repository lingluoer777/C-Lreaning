//
//  main.cpp
//  3.7.8排序案例
//
//  Created by 翎落 on 2022/7/26.
//
//案例描述：将Person自定义数据类型进行排序，Person中属性有姓名、年龄、身高
//排序规则：按照年龄进行升序，如果年龄相同按照身高进行降序

#include <iostream>
#include <list>

using namespace std;

class Person{
public:
    Person(string name,int age,double height)
    {
        m_Name=name;
        m_Age=age;
        m_Height=height;
    }
    string m_Name;
    int m_Age;
    double m_Height;
};

bool ComparePerson(Person &p1,Person &p2)
{
    if(p1.m_Age==p2.m_Age)
        //身高降序
        return p1.m_Height>p2.m_Height;
    else
        //年龄升序
        return p1.m_Age<p2.m_Age;
}

void test01()
{
    list<Person>L;
    Person p1("ZhangSan",19,1.83);
    Person p2("liSi",20,1.75);
    Person p3("WangWu",20,1.8);
    Person p4("ZhaoLiu",20,1.78);
    Person p5("QiQi",25,1.82);
    L.push_back(p1);
    L.push_back(p2);
    L.push_back(p3);
    L.push_back(p4);
    L.push_back(p5);
    
    cout << "排序前：" << endl;
    for(list<Person>::iterator it=L.begin();it!=L.end();it++)
    {
        cout << "m_Name=" << it->m_Name
             << " \tm_Age=" << it->m_Age
             << " \tm_Height=" << it->m_Height << endl;
    }
    cout << endl;
    
    L.sort(ComparePerson);
    
    cout << "排序后：" << endl;
    for(list<Person>::iterator it=L.begin();it!=L.end();it++)
    {
        cout << "m_Name=" << it->m_Name
             << " \tm_Age=" << it->m_Age
             << " \tm_Height=" << it->m_Height << endl;
    }
    cout << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
