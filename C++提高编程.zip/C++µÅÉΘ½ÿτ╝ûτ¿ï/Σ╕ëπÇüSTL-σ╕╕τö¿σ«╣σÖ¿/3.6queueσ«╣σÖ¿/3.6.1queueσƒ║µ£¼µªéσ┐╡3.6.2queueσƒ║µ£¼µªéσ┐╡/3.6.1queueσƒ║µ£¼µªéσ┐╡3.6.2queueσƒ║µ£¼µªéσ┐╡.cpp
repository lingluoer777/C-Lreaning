//
//  main.cpp
//  3.6.1queue基本概念3.6.2queue基本概念
//
//  Created by 翎落 on 2022/7/26.
//
//3.6.1queue基本概念
//Queue是一种先进先出(First In First Out,FIFO)的数据结构，他有两个出口

//                  ------------------------------->队列方向
//                  队尾                      队头
//                 _______________________________
//          -----> |_____|_____|_____|_____|_____| ----->
//          push()                                 pop()
//                 back()                  front()

//队列允许从一端新增元素，从另一端移除元素
//队列中只有队头和队尾才可以被外界使用，因此队列中不允许有遍历行为
//队列中进数据成为入队 push
//队列中出数据称为出队 pop

//3.6.2queue常用接口
//构造函数：
//   queue<T> que;                                   //queue采用模版类实现，queue对象的默认构造形式

//   queue(const queue &que);                        //拷贝构造函数
//拷贝出的queue.size()=0

//赋值操作：
//   queue& operator=(const queue &que);             //重载=操作符
//重载出的queue.size()=0

//数据存取：
//   push(elem);                                     //往队尾添加元素

//   pop();                                          //从队头移除第一个元素

//   back();                                         //返回最后一个元素

//   front();                                        //返回第一个元素

//大小操作：
//   empty();                                        //判断队列是否为空

//   size();                                         //返回队列的大小

#include <iostream>
#include <queue>

using namespace std;

class Person{
public:
    Person(string name,int age)
    {
        m_Name=name;
        m_Age=age;
    }
    string m_Name;
    int m_Age;
};

void test01()
{
    Person p1("ZhangSan",18);
    Person p2("LiSi",19);
    Person p3("WangWu",20);
    Person p4("ZhaoLiu",21);
    Person p5("QiQi",29);
    
    queue<Person>q;
    q.push(p1);
    q.push(p2);
    q.push(p3);
    q.push(p4);
    q.push(p5);
    
    while(!q.empty())
    {
        cout << "q.size()=" << q.size() << endl;
        cout << "q.front().m_Name=" << q.front().m_Name << " q.front().m_Age=" << q.front().m_Age << endl;
        cout << "q.back().m_Name=" << q.back().m_Name << " q.back().m_Age=" << q.back().m_Age << endl;
        q.pop();
    }
    
    queue<Person>q2(q);
    cout << q2.size() << endl;
    queue<Person>q3;
    q3=q;
    cout << q3.size() << endl;
}

int main(int argc, const char * argv[]) {
    test01();
    return 0;
}
